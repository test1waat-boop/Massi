import React, { useState, useEffect, useCallback } from 'react';
import { 
  StoreSettings, 
  InventoryItem, 
  Customer, 
  CustomerTransaction, 
  SaleRecord, 
  ActiveTab, 
  TransactionType 
} from './types';
import { 
  getStoredSettings, 
  saveStoredSettings,
  getStoredInventory,
  saveStoredInventory,
  getStoredCustomers,
  saveStoredCustomers,
  getStoredTransactions,
  saveStoredTransactions,
  getStoredSales,
  saveStoredSales,
  getCustomerBalance,
  createFullDatabaseBackup
} from './utils/storage';
import { saveBackupFile } from './utils/native';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { InventoryList } from './components/Inventory/InventoryList';
import { ItemModal } from './components/Inventory/ItemModal';
import { QuickSales } from './components/POS/QuickSales';
import { CustomerList } from './components/Customers/CustomerList';
import { CustomerDetailModal } from './components/Customers/CustomerDetailModal';
import { AnalyticsView } from './components/Analytics/AnalyticsView';
import { SettingsModal } from './components/Settings/SettingsModal';

export default function App() {
  // Global persistent states
  const [settings, setSettings] = useState<StoreSettings>(() => getStoredSettings());
  const [inventory, setInventory] = useState<InventoryItem[]>(() => getStoredInventory());
  const [customers, setCustomers] = useState<Customer[]>(() => getStoredCustomers());
  const [transactions, setTransactions] = useState<CustomerTransaction[]>(() => getStoredTransactions());
  const [sales, setSales] = useState<SaleRecord[]>(() => getStoredSales());

  // Navigation tab
  const [activeTab, setActiveTab] = useState<ActiveTab>('pos');

  // Modals
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    saveStoredSettings(settings);
  }, [settings]);

  useEffect(() => {
    saveStoredInventory(inventory);
  }, [inventory]);

  useEffect(() => {
    saveStoredCustomers(customers);
  }, [customers]);

  useEffect(() => {
    saveStoredTransactions(transactions);
  }, [transactions]);

  useEffect(() => {
    saveStoredSales(sales);
  }, [sales]);

  // Count active pending debts
  const pendingDebtsCount = customers.filter((c) => {
    const { netDebt } = getCustomerBalance(c.id, transactions);
    return netDebt > 0;
  }).length;

  // --- Handlers for Inventory ---
  const handleSaveItem = (item: InventoryItem) => {
    setInventory((prev) => {
      const existsIndex = prev.findIndex((i) => i.id === item.id);
      if (existsIndex > -1) {
        const next = [...prev];
        next[existsIndex] = item;
        return next;
      }
      return [item, ...prev];
    });
  };

  const handleDeleteItem = (id: string) => {
    setInventory((prev) => prev.filter((i) => i.id !== id));
  };

  const handleUpdateStock = (id: string, delta: number) => {
    setInventory((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newQty = Math.max(0, item.stockQuantity + delta);
          return { ...item, stockQuantity: newQty, updatedAt: new Date().toISOString() };
        }
        return item;
      })
    );
  };

  // --- Handlers for Customers & Ledger ---
  const handleAddCustomer = (data: { name: string; phone: string; notes?: string }): Customer => {
    const newCust: Customer = {
      id: `cust-${Date.now()}`,
      name: data.name,
      phone: data.phone,
      notes: data.notes || '',
      createdAt: new Date().toISOString(),
    };

    setCustomers((prev) => [newCust, ...prev]);
    return newCust;
  };

  const handleDeleteCustomer = (customerId: string) => {
    setCustomers((prev) => prev.filter((c) => c.id !== customerId));
    setTransactions((prev) => prev.filter((t) => t.customerId !== customerId));
    if (selectedCustomer?.id === customerId) {
      setSelectedCustomer(null);
    }
  };

  const handleAddTransaction = (
    customerId: string,
    type: TransactionType,
    amount: number,
    note: string
  ) => {
    const newTx: CustomerTransaction = {
      id: `tx-${Date.now()}`,
      customerId,
      type,
      amount,
      date: new Date().toISOString(),
      note,
    };

    setTransactions((prev) => [newTx, ...prev]);
  };

  const handleDeleteTransaction = (transactionId: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== transactionId));
  };

  // --- Handlers for POS Sale Completion ---
  const handleCompleteSale = (
    sale: SaleRecord,
    newCustomerData?: { name: string; phone: string }
  ) => {
    // 1. Decrement inventory stock for each sold item
    setInventory((prev) =>
      prev.map((item) => {
        const soldItem = sale.items.find((si) => si.itemId === item.id);
        if (soldItem) {
          const newQty = Math.max(0, item.stockQuantity - soldItem.quantity);
          return { ...item, stockQuantity: newQty, updatedAt: new Date().toISOString() };
        }
        return item;
      })
    );

    // 2. If credit sale, ensure customer exists and record debit transaction
    let customerId = sale.customerId;

    if (sale.paymentType === 'credit') {
      if (newCustomerData && !customerId) {
        const createdCustomer = handleAddCustomer({
          name: newCustomerData.name,
          phone: newCustomerData.phone,
          notes: 'تمت إضافته أثناء بيع بالدين',
        });
        customerId = createdCustomer.id;
        sale.customerId = customerId;
        sale.customerName = createdCustomer.name;
      }

      if (customerId) {
        // Build readable transaction note summarizing items
        const itemSummary = sale.items
          .map((i) => `${i.itemName}${i.color ? ` (${i.color})` : ''} x${i.quantity}`)
          .join(', ');

        const creditTx: CustomerTransaction = {
          id: `tx-${Date.now()}`,
          customerId,
          type: 'given', // أعطيت - debit
          amount: sale.totalAmount,
          date: sale.date,
          note: `فاتورة بيع بالدين #${sale.id.slice(-4)}: ${itemSummary}`,
          saleId: sale.id,
        };

        setTransactions((prev) => [creditTx, ...prev]);
      }
    }

    // 3. Save sale record
    setSales((prev) => [sale, ...prev]);
  };

  // --- Database Restore & Backup ---
  const handleDatabaseRestored = useCallback(() => {
    setSettings(getStoredSettings());
    setInventory(getStoredInventory());
    setCustomers(getStoredCustomers());
    setTransactions(getStoredTransactions());
    setSales(getStoredSales());
  }, []);

  const handleQuickBackup = () => {
    const backup = createFullDatabaseBackup();
    const jsonString = JSON.stringify(backup, null, 2);
    const dateStr = new Date().toISOString().split('T')[0];
    void saveBackupFile(`masy-backup-${dateStr}.json`, jsonString);
  };

  return (
    <div className="min-h-screen bg-[#08090d] text-slate-100 flex flex-col antialiased selection:bg-amber-500/20 selection:text-amber-300">
      {/* Mobile-First Shell Container */}
      <div className="w-full max-w-lg mx-auto min-h-screen flex flex-col bg-[#0b0d13] sm:border-x sm:border-slate-800/80 sm:shadow-2xl relative">
        
        {/* App Header */}
        <Header
          settings={settings}
          onOpenSettings={() => setIsSettingsModalOpen(true)}
          onQuickBackup={handleQuickBackup}
          pendingDebtsCount={pendingDebtsCount}
        />

        {/* Main Content Area */}
        <main className="flex-1 p-3.5 sm:p-4 overflow-x-hidden">
          {activeTab === 'inventory' && (
            <InventoryList
              items={inventory}
              currencySymbol={settings.currency.symbol}
              onAddItem={() => {
                setEditingItem(null);
                setIsItemModalOpen(true);
              }}
              onEditItem={(item) => {
                setEditingItem(item);
                setIsItemModalOpen(true);
              }}
              onDeleteItem={handleDeleteItem}
              onUpdateStock={handleUpdateStock}
            />
          )}

          {activeTab === 'pos' && (
            <QuickSales
              items={inventory}
              customers={customers}
              currencySymbol={settings.currency.symbol}
              onCompleteSale={handleCompleteSale}
              onAddNewCustomer={(name, phone) => handleAddCustomer({ name, phone })}
            />
          )}

          {activeTab === 'customers' && (
            <CustomerList
              customers={customers}
              transactions={transactions}
              settings={settings}
              onSelectCustomer={(cust) => setSelectedCustomer(cust)}
              onAddCustomer={handleAddCustomer}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsView
              inventory={inventory}
              customers={customers}
              transactions={transactions}
              sales={sales}
              settings={settings}
            />
          )}

          {activeTab === 'settings' && (
            <div className="space-y-4 pb-20">
              <div className="p-5 rounded-2xl bg-[#11131a] border border-amber-500/20">
                <h3 className="font-extrabold text-white text-base mb-1">إعدادات النظام والنسخ الاحتياطي</h3>
                <p className="text-xs text-slate-400 mb-4">
                  إدارة اسم وشعار المتجر، مفتاح الاتصال للواتساب، والنسخ الاحتياطي السحابي عبر Google Drive.
                </p>
                <button
                  onClick={() => setIsSettingsModalOpen(true)}
                  className="w-full h-12 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition-transform"
                >
                  فتح لوحة الإعدادات والنسخ
                </button>
              </div>

              {/* Quick Info Box */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-2">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>معلومات المتجر الحالية:</span>
                  <span className="text-amber-400 font-mono">{settings.currency.symbol} ({settings.currency.name})</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  كود الدولة للواتساب: <span className="font-mono text-slate-200">{settings.countryCode}</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  إجمالي العملاء: <span className="font-mono text-slate-200">{customers.length} عميل</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  إجمالي أصناف المخزون: <span className="font-mono text-slate-200">{inventory.length} صنف</span>
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Bottom Navigation */}
        <Navigation
          activeTab={activeTab}
          onChangeTab={(tab) => {
            if (tab === 'settings') {
              setIsSettingsModalOpen(true);
            } else {
              setActiveTab(tab);
            }
          }}
          pendingDebtsCount={pendingDebtsCount}
        />

        {/* Product Add/Edit Modal */}
        <ItemModal
          isOpen={isItemModalOpen}
          itemToEdit={editingItem}
          currencySymbol={settings.currency.symbol}
          onClose={() => {
            setIsItemModalOpen(false);
            setEditingItem(null);
          }}
          onSave={handleSaveItem}
        />

        {/* Customer Detail & Debt Ledger Modal */}
        {selectedCustomer && (
          <CustomerDetailModal
            customer={selectedCustomer}
            transactions={transactions}
            settings={settings}
            isOpen={selectedCustomer !== null}
            onClose={() => setSelectedCustomer(null)}
            onAddTransaction={handleAddTransaction}
            onDeleteTransaction={handleDeleteTransaction}
            onDeleteCustomer={handleDeleteCustomer}
          />
        )}

        {/* Settings & Backup Modal */}
        <SettingsModal
          settings={settings}
          isOpen={isSettingsModalOpen}
          onClose={() => setIsSettingsModalOpen(false)}
          onSaveSettings={(newSettings) => setSettings(newSettings)}
          onDatabaseRestored={handleDatabaseRestored}
        />
      </div>
    </div>
  );
}
