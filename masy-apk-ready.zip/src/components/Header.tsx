import React from 'react';
import { Gem, Settings, Database, RefreshCw } from 'lucide-react';
import { StoreSettings } from '../types';

interface HeaderProps {
  settings: StoreSettings;
  onOpenSettings: () => void;
  onQuickBackup?: () => void;
  pendingDebtsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onOpenSettings,
  onQuickBackup,
  pendingDebtsCount = 0,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#0c0e14]/90 backdrop-blur-xl border-b border-amber-500/15 transition-all">
      <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
        {/* Brand Zone */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative group cursor-pointer" onClick={onOpenSettings}>
            {settings.storeLogo ? (
              <img
                src={settings.storeLogo}
                alt={settings.storeName}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-xl object-cover border border-amber-400/40 shadow-sm"
              />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/20 text-slate-950 font-black">
                <Gem className="w-5 h-5 text-slate-950 stroke-[2.5]" />
              </div>
            )}
            <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-[#0c0e14]" />
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="text-base font-extrabold text-white tracking-tight truncate">
                {settings.storeName || 'ماسي'}
              </h1>
              <span className="text-[11px] font-mono text-amber-400/90 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/20 shrink-0">
                {settings.currency.symbol}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate">
              نظام إدارة المخزون والمبيعات والدفتر المالي
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          {pendingDebtsCount > 0 && (
            <div 
              onClick={onOpenSettings}
              className="hidden xs:flex items-center gap-1 text-[11px] font-medium text-rose-300 bg-rose-500/10 border border-rose-500/20 px-2 py-1 rounded-lg"
            >
              <span>{pendingDebtsCount} ديون نشطة</span>
            </div>
          )}

          {onQuickBackup && (
            <button
              onClick={onQuickBackup}
              title="تصدير نسخة احتياطية سريعة"
              className="h-9 w-9 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-amber-400 hover:border-amber-500/30 flex items-center justify-center transition-colors active:scale-95"
            >
              <Database className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={onOpenSettings}
            title="إعدادات المتجر والنسخ الاحتياطي"
            className="h-9 w-9 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-amber-400 hover:border-amber-500/30 flex items-center justify-center transition-colors active:scale-95"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
