import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  LayoutGrid, 
  List, 
  Edit3, 
  Trash2, 
  Package, 
  AlertTriangle,
  Shirt,
  Sparkles
} from 'lucide-react';
import { InventoryItem } from '../../types';

interface InventoryListProps {
  items: InventoryItem[];
  currencySymbol: string;
  onAddItem: () => void;
  onEditItem: (item: InventoryItem) => void;
  onDeleteItem: (id: string) => void;
  onUpdateStock: (id: string, delta: number) => void;
}

export const InventoryList: React.FC<InventoryListProps> = ({
  items,
  currencySymbol,
  onAddItem,
  onEditItem,
  onDeleteItem,
  onUpdateStock,
}) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Extract unique categories
  const categories = ['all', ...Array.from(new Set(items.map((i) => i.category || 'عام')))];

  const filteredItems = items.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.colors.some((c) => c.toLowerCase().includes(searchQuery.toLowerCase())) ||
      item.sizes.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'all' || (item.category || 'عام') === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const totalStockUnits = items.reduce((sum, i) => sum + (Number(i.stockQuantity) || 0), 0);
  const totalCostValue = items.reduce((sum, i) => sum + (Number(i.costPrice) || 0) * (Number(i.stockQuantity) || 0), 0);
  const totalPotentialProfit = items.reduce((sum, i) => {
    const margin = Math.max(0, (Number(i.sellingPrice) || 0) - (Number(i.costPrice) || 0));
    return sum + margin * (Number(i.stockQuantity) || 0);
  }, 0);

  return (
    <div className="space-y-4 pb-20">
      {/* Top Inventory Stats Bar */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <span className="text-[11px] text-slate-400 font-medium">إجمالي الأصناف</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-xl font-black text-white font-mono tabular-nums">{items.length}</span>
            <span className="text-[10px] text-slate-400">صنف ({totalStockUnits} قطعة)</span>
          </div>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <span className="text-[11px] text-slate-400 font-medium">قيمة المخزون (تكلفة)</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-lg font-black text-amber-300 font-mono tabular-nums">
              {totalCostValue.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400">{currencySymbol}</span>
          </div>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900/90 border border-emerald-500/20 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/30 flex flex-col justify-between">
          <span className="text-[11px] text-emerald-400 font-medium">الربح المتوقع</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-lg font-black text-emerald-300 font-mono tabular-nums">
              +{totalPotentialProfit.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400">{currencySymbol}</span>
          </div>
        </div>
      </div>

      {/* Action Bar: Search, Category pills, View Mode & Add Button */}
      <div className="flex flex-col gap-2.5">
        <div className="flex items-center gap-2">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
            <input
              type="text"
              placeholder="ابحث عن صنف، مقاس أو لون..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pr-9 pl-3 rounded-xl bg-slate-900/90 border border-slate-800 text-white placeholder-slate-500 text-xs focus:border-amber-400 focus:outline-none"
            />
          </div>

          {/* View Mode Switcher */}
          <div className="flex items-center p-1 rounded-xl bg-slate-900 border border-slate-800 shrink-0">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'grid' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
              title="عرض شبكي"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'list' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
              title="عرض قائمة"
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          {/* Add Item Button */}
          <button
            onClick={onAddItem}
            className="h-10 px-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 active:scale-95 transition-transform shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span className="hidden xs:inline">صنف جديد</span>
          </button>
        </div>

        {/* Category Tabs */}
        {categories.length > 2 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-amber-400/20 text-amber-300 border border-amber-400/30'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {cat === 'all' ? 'جميع الأصناف' : cat}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Inventory Items Content */}
      {filteredItems.length === 0 ? (
        <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800/80 my-4">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/10 flex items-center justify-center text-amber-400 mb-3">
            <Package className="w-7 h-7" />
          </div>
          <h4 className="text-white font-bold text-sm mb-1">لا توجد أصناف مطابقة</h4>
          <p className="text-xs text-slate-400 mb-4">
            {searchQuery ? 'جرب البحث بكلمة أخرى أو أضف صنفاً جديداً' : 'المخزن فارغ حالياً، ابدأ بإضافة الأصناف'}
          </p>
          <button
            onClick={onAddItem}
            className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            إضافة صنف الآن
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        /* GRID VIEW */
        <div className="grid grid-cols-2 gap-3">
          {filteredItems.map((item) => {
            const isLowStock = item.stockQuantity <= 3;
            const isOutOfStock = item.stockQuantity <= 0;
            const profit = Math.max(0, item.sellingPrice - item.costPrice);

            return (
              <div
                key={item.id}
                className="rounded-2xl bg-[#11131a] border border-slate-800/90 hover:border-amber-500/30 overflow-hidden flex flex-col justify-between transition-all group"
              >
                {/* Image & Badges */}
                <div className="relative aspect-square w-full bg-slate-950 flex items-center justify-center overflow-hidden">
                  {item.image ? (
                    <img
                      src={item.image}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-slate-900 to-slate-950 flex flex-col items-center justify-center text-slate-600">
                      <Shirt className="w-10 h-10 mb-1 opacity-40 text-amber-400" />
                      <span className="text-[10px] text-slate-500 font-medium">{item.category || 'صنف'}</span>
                    </div>
                  )}

                  {/* Stock status tag */}
                  <div className="absolute top-2 right-2">
                    {isOutOfStock ? (
                      <span className="text-[10px] bg-rose-500/90 text-white font-bold px-2 py-0.5 rounded-md shadow-sm">
                        نفد المخزون
                      </span>
                    ) : isLowStock ? (
                      <span className="text-[10px] bg-amber-500/90 text-slate-950 font-bold px-2 py-0.5 rounded-md shadow-sm">
                        متبقي {item.stockQuantity} فقط
                      </span>
                    ) : (
                      <span className="text-[10px] bg-slate-900/80 backdrop-blur-md text-slate-300 font-mono px-2 py-0.5 rounded-md border border-slate-700/60">
                        {item.stockQuantity} ق
                      </span>
                    )}
                  </div>

                  {/* Quick Edit/Delete buttons on hover/touch */}
                  <div className="absolute top-2 left-2 flex items-center gap-1">
                    <button
                      onClick={() => onEditItem(item)}
                      className="w-7 h-7 rounded-lg bg-black/60 backdrop-blur-md text-white hover:text-amber-300 flex items-center justify-center transition-colors"
                      title="تعديل الصنف"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeleteConfirmId(item.id)}
                      className="w-7 h-7 rounded-lg bg-black/60 backdrop-blur-md text-white hover:text-rose-400 flex items-center justify-center transition-colors"
                      title="حذف الصنف"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Card Details */}
                <div className="p-3 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-bold text-white text-xs line-clamp-1 group-hover:text-amber-300 transition-colors">
                      {item.name}
                    </h4>

                    {/* Colors & Sizes preview */}
                    <div className="flex items-center gap-1 mt-1 text-[10px] text-slate-400 overflow-hidden">
                      {item.sizes.length > 0 && (
                        <span className="truncate">{item.sizes.slice(0, 3).join(', ')}</span>
                      )}
                      {item.colors.length > 0 && (
                        <>
                          <span className="text-slate-600">·</span>
                          <span className="truncate">{item.colors.slice(0, 2).join(', ')}</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Price Row */}
                  <div className="mt-2.5 pt-2 border-t border-slate-800/80">
                    <div className="flex items-baseline justify-between">
                      <div className="flex items-baseline gap-1">
                        <span className="text-base font-extrabold text-amber-300 font-mono tabular-nums">
                          {item.sellingPrice}
                        </span>
                        <span className="text-[10px] text-slate-400">{currencySymbol}</span>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-mono">
                        +{profit} ربح
                      </span>
                    </div>

                    {/* Quick Stock Controls */}
                    <div className="flex items-center justify-between mt-2 pt-1.5 bg-slate-900/60 px-2 py-1 rounded-xl">
                      <button
                        onClick={() => onUpdateStock(item.id, -1)}
                        disabled={item.stockQuantity <= 0}
                        className="w-6 h-6 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 flex items-center justify-center font-bold text-xs disabled:opacity-30 active:scale-90"
                      >
                        -
                      </button>
                      <span className="text-xs font-mono font-bold text-slate-200">
                        الكمية: {item.stockQuantity}
                      </span>
                      <button
                        onClick={() => onUpdateStock(item.id, 1)}
                        className="w-6 h-6 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 flex items-center justify-center font-bold text-xs active:scale-90"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* LIST VIEW */
        <div className="space-y-2">
          {filteredItems.map((item) => {
            const isLowStock = item.stockQuantity <= 3;
            const profit = Math.max(0, item.sellingPrice - item.costPrice);

            return (
              <div
                key={item.id}
                className="p-3 rounded-2xl bg-[#11131a] border border-slate-800/90 hover:border-amber-500/30 flex items-center gap-3 transition-colors"
              >
                {/* Thumbnail */}
                <div className="w-14 h-14 rounded-xl bg-slate-950 overflow-hidden shrink-0 flex items-center justify-center">
                  {item.image ? (
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  ) : (
                    <Shirt className="w-6 h-6 text-amber-400/40" />
                  )}
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="font-bold text-white text-xs truncate">{item.name}</h4>
                    <div className="flex items-baseline gap-1 shrink-0">
                      <span className="text-sm font-bold text-amber-300 font-mono tabular-nums">
                        {item.sellingPrice}
                      </span>
                      <span className="text-[10px] text-slate-400">{currencySymbol}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                    <span>التكلفة: {item.costPrice} {currencySymbol}</span>
                    <span>·</span>
                    <span className="text-emerald-400 font-mono">الربح: +{profit} {currencySymbol}</span>
                  </div>

                  {/* Stock and sizes */}
                  <div className="flex items-center justify-between mt-1.5">
                    <span className={`text-[11px] font-mono font-semibold ${isLowStock ? 'text-amber-400' : 'text-slate-300'}`}>
                      المخزون: {item.stockQuantity} قطعة
                    </span>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => onUpdateStock(item.id, -1)}
                        disabled={item.stockQuantity <= 0}
                        className="w-6 h-6 rounded-md bg-slate-800 text-slate-200 text-xs flex items-center justify-center disabled:opacity-30"
                      >
                        -
                      </button>
                      <button
                        onClick={() => onUpdateStock(item.id, 1)}
                        className="w-6 h-6 rounded-md bg-slate-800 text-slate-200 text-xs flex items-center justify-center"
                      >
                        +
                      </button>
                      <button
                        onClick={() => onEditItem(item)}
                        className="w-7 h-7 rounded-md bg-slate-800 text-slate-300 hover:text-amber-300 text-xs flex items-center justify-center ml-1"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirmId(item.id)}
                        className="w-7 h-7 rounded-md bg-slate-800 text-slate-300 hover:text-rose-400 text-xs flex items-center justify-center"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Item Confirmation Dialog */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-xs bg-[#12141c] border border-rose-500/30 rounded-2xl p-5 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-400 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-white text-sm mb-1">هل تريد بالتأكيد حذف هذا الصنف؟</h4>
            <p className="text-xs text-slate-400 mb-4">لن تتمكن من استرجاع بيانات هذا المنتج بعد الحذف.</p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 h-10 rounded-xl bg-slate-800 text-slate-300 font-semibold text-xs"
              >
                إلغاء
              </button>
              <button
                onClick={() => {
                  onDeleteItem(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="flex-1 h-10 rounded-xl bg-rose-600 text-white font-bold text-xs"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
