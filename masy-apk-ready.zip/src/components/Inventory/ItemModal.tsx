import React, { useState, useEffect, useRef } from 'react';
import { X, Upload, Plus, Trash2, Camera, Calculator } from 'lucide-react';
import { InventoryItem } from '../../types';
import { CalculatorModal } from '../Common/CalculatorModal';

interface ItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: InventoryItem) => void;
  itemToEdit?: InventoryItem | null;
  currencySymbol: string;
}

const COMMON_SIZES = ['S', 'M', 'L', 'XL', 'XXL', '38', '40', '42', '44', 'حر / مقاس موحد'];
const COMMON_COLORS = ['أسود', 'أبيض', 'كحلي', 'بيج', 'رمادي', 'زيتي', 'نبيذي', 'بني', 'أزرق سماوي'];

export const ItemModal: React.FC<ItemModalProps> = ({
  isOpen,
  onClose,
  onSave,
  itemToEdit,
  currencySymbol,
}) => {
  const [name, setName] = useState('');
  const [colors, setColors] = useState<string[]>([]);
  const [colorInput, setColorInput] = useState('');
  const [sizes, setSizes] = useState<string[]>([]);
  const [sizeInput, setSizeInput] = useState('');
  const [stockQuantity, setStockQuantity] = useState<number>(1);
  const [costPrice, setCostPrice] = useState<number>(0);
  const [sellingPrice, setSellingPrice] = useState<number>(0);
  const [image, setImage] = useState<string | null>(null);
  const [category, setCategory] = useState('');
  
  // Calculator integration
  const [calculatorTarget, setCalculatorTarget] = useState<'cost' | 'selling' | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (itemToEdit) {
      setName(itemToEdit.name);
      setColors(itemToEdit.colors || []);
      setSizes(itemToEdit.sizes || []);
      setStockQuantity(itemToEdit.stockQuantity || 0);
      setCostPrice(itemToEdit.costPrice || 0);
      setSellingPrice(itemToEdit.sellingPrice || 0);
      setImage(itemToEdit.image || null);
      setCategory(itemToEdit.category || '');
    } else {
      setName('');
      setColors(['أبيض', 'أسود']);
      setSizes(['M', 'L', 'XL']);
      setStockQuantity(10);
      setCostPrice(100);
      setSellingPrice(200);
      setImage(null);
      setCategory('ملابس');
    }
  }, [itemToEdit, isOpen]);

  if (!isOpen) return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Compress & read as base64
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 500;
        const MAX_HEIGHT = 500;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height = Math.round((height * MAX_WIDTH) / width);
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width = Math.round((width * MAX_HEIGHT) / height);
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
        setImage(dataUrl);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleAddColor = (col: string) => {
    const trimmed = col.trim();
    if (trimmed && !colors.includes(trimmed)) {
      setColors([...colors, trimmed]);
      setColorInput('');
    }
  };

  const handleRemoveColor = (col: string) => {
    setColors(colors.filter((c) => c !== col));
  };

  const handleAddSize = (sz: string) => {
    const trimmed = sz.trim();
    if (trimmed && !sizes.includes(trimmed)) {
      setSizes([...sizes, trimmed]);
      setSizeInput('');
    }
  };

  const handleRemoveSize = (sz: string) => {
    setSizes(sizes.filter((s) => s !== sz));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const item: InventoryItem = {
      id: itemToEdit ? itemToEdit.id : `item-${Date.now()}`,
      name: name.trim(),
      colors,
      image,
      sizes,
      stockQuantity: Number(stockQuantity) || 0,
      costPrice: Number(costPrice) || 0,
      sellingPrice: Number(sellingPrice) || 0,
      category: category.trim() || 'عام',
      createdAt: itemToEdit ? itemToEdit.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSave(item);
    onClose();
  };

  const potentialProfitPerUnit = Math.max(0, sellingPrice - costPrice);
  const totalItemProfit = potentialProfitPerUnit * stockQuantity;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-[#11131a] border border-amber-500/20 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[92vh] sm:max-h-[88vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#0d0e14]/60 sticky top-0 z-10">
          <div>
            <h3 className="font-extrabold text-white text-base">
              {itemToEdit ? 'تعديل بيانات الصنف' : 'إضافة صنف جديد للمخزن'}
            </h3>
            <p className="text-xs text-slate-400">سجل المقاسات، الألوان، التكلفة والكميات بدقة</p>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto flex-1">
          {/* Image Upload Zone */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">صورة المنتج</label>
            <div className="flex items-center gap-4">
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="w-24 h-24 rounded-2xl border-2 border-dashed border-amber-500/30 hover:border-amber-400/60 bg-slate-900/60 flex flex-col items-center justify-center cursor-pointer overflow-hidden transition-colors group relative"
              >
                {image ? (
                  <>
                    <img src={image} alt="معاينة" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <Camera className="w-6 h-6 text-white" />
                    </div>
                  </>
                ) : (
                  <>
                    <Camera className="w-7 h-7 text-amber-400/70 group-hover:text-amber-400 transition-colors mb-1" />
                    <span className="text-[10px] text-slate-400">اختر صورة</span>
                  </>
                )}
              </div>
              <div className="flex-1 text-xs text-slate-400">
                <p className="mb-2">ارفع صورة واضحة من الكاميرا أو المعرض لتسهيل البيع السريع والتعرف على الصنف.</p>
                {image && (
                  <button
                    type="button"
                    onClick={() => setImage(null)}
                    className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    إزالة الصورة
                  </button>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>
            </div>
          </div>

          {/* Item Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              اسم الصنف / المنتج <span className="text-amber-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="مثال: قميص كتان تركي كاجوال"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl bg-slate-900 border border-slate-700/80 text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none text-sm font-medium"
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">التصنيف</label>
            <input
              type="text"
              placeholder="مثال: قمصان، بناطيل، فساتين، إكسسوارات"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl bg-slate-900 border border-slate-700/80 text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none text-sm"
            />
          </div>

          {/* Pricing Row with Calculator Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">سعر التكلفة</label>
                <button
                  type="button"
                  onClick={() => setCalculatorTarget('cost')}
                  className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1"
                >
                  <Calculator className="w-3 h-3" />
                  حاسبة
                </button>
              </div>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={costPrice || ''}
                  onChange={(e) => setCostPrice(parseFloat(e.target.value) || 0)}
                  className="w-full h-11 px-3.5 pl-8 rounded-xl bg-slate-900 border border-slate-700/80 text-white focus:border-amber-400 focus:outline-none text-sm font-mono tabular-nums"
                />
                <span className="absolute left-3 top-3 text-xs text-slate-400">{currencySymbol}</span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">سعر البيع</label>
                <button
                  type="button"
                  onClick={() => setCalculatorTarget('selling')}
                  className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1"
                >
                  <Calculator className="w-3 h-3" />
                  حاسبة
                </button>
              </div>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={sellingPrice || ''}
                  onChange={(e) => setSellingPrice(parseFloat(e.target.value) || 0)}
                  className="w-full h-11 px-3.5 pl-8 rounded-xl bg-slate-900 border border-slate-700/80 text-white focus:border-amber-400 focus:outline-none text-sm font-mono tabular-nums font-bold text-amber-300"
                />
                <span className="absolute left-3 top-3 text-xs text-slate-400">{currencySymbol}</span>
              </div>
            </div>
          </div>

          {/* Profit Preview */}
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs flex items-center justify-between text-slate-300">
            <span>ربح القطعة المتوقع:</span>
            <span className="font-bold text-emerald-400 font-mono tabular-nums">
              +{potentialProfitPerUnit} {currencySymbol} (إجمالي الدفعة: +{totalItemProfit} {currencySymbol})
            </span>
          </div>

          {/* Stock Quantity */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">الكمية المتوفرة بالمخزن</label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setStockQuantity(Math.max(0, stockQuantity - 1))}
                className="w-11 h-11 rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700 flex items-center justify-center font-bold text-lg active:scale-95"
              >
                -
              </button>
              <input
                type="number"
                min="0"
                value={stockQuantity}
                onChange={(e) => setStockQuantity(parseInt(e.target.value) || 0)}
                className="flex-1 h-11 px-3 rounded-xl bg-slate-900 border border-slate-700/80 text-white text-center font-mono text-base font-bold focus:border-amber-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setStockQuantity(stockQuantity + 1)}
                className="w-11 h-11 rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700 flex items-center justify-center font-bold text-lg active:scale-95"
              >
                +
              </button>
            </div>
          </div>

          {/* Colors */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">الألوان المتاحة</label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {colors.map((col) => (
                <span
                  key={col}
                  className="inline-flex items-center gap-1.5 text-xs bg-slate-800 text-slate-200 px-2.5 py-1 rounded-lg border border-slate-700"
                >
                  {col}
                  <button
                    type="button"
                    onClick={() => handleRemoveColor(col)}
                    className="text-slate-400 hover:text-rose-400"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
            {/* Quick add common colors */}
            <div className="flex flex-wrap gap-1 mb-2">
              {COMMON_COLORS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleAddColor(preset)}
                  className="text-[11px] px-2 py-0.5 rounded-md bg-slate-900 text-slate-400 hover:text-amber-300 hover:bg-slate-800 border border-slate-800"
                >
                  +{preset}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="أضف لوناً مخصصاً..."
                value={colorInput}
                onChange={(e) => setColorInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddColor(colorInput);
                  }
                }}
                className="flex-1 h-9 px-3 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:border-amber-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => handleAddColor(colorInput)}
                className="px-3 h-9 rounded-lg bg-slate-800 text-amber-400 hover:bg-slate-700 text-xs font-semibold"
              >
                إضافة
              </button>
            </div>
          </div>

          {/* Sizes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">المقاسات المتاحة</label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {sizes.map((sz) => (
                <span
                  key={sz}
                  className="inline-flex items-center gap-1.5 text-xs bg-amber-500/10 text-amber-300 px-2.5 py-1 rounded-lg border border-amber-500/20 font-mono"
                >
                  {sz}
                  <button
                    type="button"
                    onClick={() => handleRemoveSize(sz)}
                    className="text-amber-400/80 hover:text-rose-400"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
            {/* Quick add common sizes */}
            <div className="flex flex-wrap gap-1 mb-2">
              {COMMON_SIZES.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleAddSize(preset)}
                  className="text-[11px] px-2 py-0.5 rounded-md bg-slate-900 text-slate-400 hover:text-amber-300 hover:bg-slate-800 border border-slate-800 font-mono"
                >
                  +{preset}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="أضف مقاساً آخر..."
                value={sizeInput}
                onChange={(e) => setSizeInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSize(sizeInput);
                  }
                }}
                className="flex-1 h-9 px-3 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:border-amber-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => handleAddSize(sizeInput)}
                className="px-3 h-9 rounded-lg bg-slate-800 text-amber-400 hover:bg-slate-700 text-xs font-semibold"
              >
                إضافة
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-2 sticky bottom-0 bg-[#11131a] pb-2">
            <button
              type="submit"
              className="w-full h-12 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 active:scale-[0.98] transition-transform"
            >
              {itemToEdit ? 'حفظ التعديلات' : 'إضافة الصنف للمخزن'}
            </button>
          </div>
        </form>
      </div>

      {/* Built-in Calculator Popup for Price Fields */}
      <CalculatorModal
        isOpen={calculatorTarget !== null}
        initialValue={calculatorTarget === 'cost' ? costPrice : sellingPrice}
        currencySymbol={currencySymbol}
        title={calculatorTarget === 'cost' ? 'حاسبة سعر التكلفة' : 'حاسبة سعر البيع'}
        onClose={() => setCalculatorTarget(null)}
        onConfirm={(val) => {
          if (calculatorTarget === 'cost') {
            setCostPrice(val);
          } else if (calculatorTarget === 'selling') {
            setSellingPrice(val);
          }
          setCalculatorTarget(null);
        }}
      />
    </div>
  );
};
