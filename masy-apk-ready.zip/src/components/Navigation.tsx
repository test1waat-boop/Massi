import React from 'react';
import { Package, Zap, Users, BarChart3, Settings2 } from 'lucide-react';
import { ActiveTab } from '../types';

interface NavigationProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  pendingDebtsCount?: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onChangeTab,
  pendingDebtsCount = 0,
}) => {
  const tabs = [
    {
      id: 'inventory' as ActiveTab,
      label: 'المخزن',
      icon: Package,
    },
    {
      id: 'pos' as ActiveTab,
      label: 'بيع سريع',
      icon: Zap,
      highlight: true,
    },
    {
      id: 'customers' as ActiveTab,
      label: 'العملاء والديون',
      icon: Users,
      badge: pendingDebtsCount > 0 ? pendingDebtsCount : undefined,
    },
    {
      id: 'analytics' as ActiveTab,
      label: 'الإحصائيات',
      icon: BarChart3,
    },
    {
      id: 'settings' as ActiveTab,
      label: 'الإعدادات',
      icon: Settings2,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0c0e14]/95 backdrop-blur-xl border-t border-slate-800/80 pb-safe">
      <div className="max-w-md mx-auto grid grid-cols-5 items-center h-16 px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => {
                if (typeof window !== 'undefined' && 'vibrate' in navigator) {
                  try { navigator.vibrate(10); } catch {}
                }
                onChangeTab(tab.id);
              }}
              className={`relative flex flex-col items-center justify-center h-full w-full transition-all group py-1 active:scale-95 ${
                isActive ? 'text-amber-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.highlight && (
                <div className={`absolute -top-3 w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  isActive 
                    ? 'bg-gradient-to-tr from-amber-500 to-amber-300 text-slate-950 shadow-lg shadow-amber-500/30 scale-105' 
                    : 'bg-slate-850 text-amber-400 border border-amber-500/30'
                }`}>
                  <Icon className="w-5 h-5 stroke-[2.5]" />
                </div>
              )}

              {!tab.highlight && (
                <div className="relative">
                  <Icon className={`w-5 h-5 transition-transform duration-200 ${isActive ? 'scale-110' : 'group-hover:scale-105'}`} />
                  {tab.badge !== undefined && (
                    <span className="absolute -top-1 -right-2 bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full min-w-4 text-center">
                      {tab.badge}
                    </span>
                  )}
                </div>
              )}

              <span className={`text-[10px] font-semibold tracking-tight transition-colors whitespace-nowrap mt-1 ${
                tab.highlight ? 'mt-7' : ''
              } ${isActive ? 'text-amber-400 font-bold' : 'text-slate-400'}`}>
                {tab.label}
              </span>

              {isActive && !tab.highlight && (
                <span className="absolute bottom-1 w-1 h-1 rounded-full bg-amber-400"></span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
