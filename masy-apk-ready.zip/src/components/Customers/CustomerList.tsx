import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  UserPlus, 
  Contact, 
  ChevronLeft, 
  ArrowUpDown, 
  Calendar, 
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { Customer, CustomerTransaction, StoreSettings } from '../../types';
import { getCustomerBalance } from '../../utils/storage';
import { pickDeviceContact } from '../../utils/contacts';

interface CustomerListProps {
  customers: Customer[];
  transactions: CustomerTransaction[];
  settings: StoreSettings;
  onSelectCustomer: (customer: Customer) => void;
  onAddCustomer: (customerData: { name: string; phone: string; notes?: string }) => void;
}

type TimeFilter = 'newest' | 'oldest' | 'today' | 'week' | 'month';

export const CustomerList: React.FC<CustomerListProps> = ({
  customers,
  transactions,
  settings,
  onSelectCustomer,
  onAddCustomer,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('newest');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newNotes, setNewNotes] = useState('');

  // Device Contacts Import
  const handleImportContact = async () => {
    try {
      const contact = await pickDeviceContact();
      if (contact && contact.name) {
        onAddCustomer({
          name: contact.name,
          phone: contact.phone || '',
          notes: 'مستورد من جهات الاتصال',
        });
      } else {
        // Fallback open manual modal with phone hint
        setIsAddModalOpen(true);
      }
    } catch {
      setIsAddModalOpen(true);
    }
  };

  // Filter & Sort Logic
  const filteredAndSortedCustomers = customers
    .filter((c) => {
      const matchSearch =
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.phone && c.phone.includes(searchQuery)) ||
        (c.notes && c.notes.toLowerCase().includes(searchQuery.toLowerCase()));

      if (!matchSearch) return false;

      const createdTime = new Date(c.createdAt).getTime();
      const now = Date.now();
      const dayMs = 24 * 60 * 60 * 1000;

      if (timeFilter === 'today') {
        const todayStart = new Date();
        todayStart.setHours(0, 0, 0, 0);
        return createdTime >= todayStart.getTime();
      }
      if (timeFilter === 'week') {
        return createdTime >= now - 7 * dayMs;
      }
      if (timeFilter === 'month') {
        return createdTime >= now - 30 * dayMs;
      }

      return true;
    })
    .sort((a, b) => {
      const timeA = new Date(a.createdAt).getTime();
      const timeB = new Date(b.createdAt).getTime();

      if (timeFilter === 'oldest') {
        return timeA - timeB; // Oldest first
      }

      // Default: most recently added customer appearing first
      return timeB - timeA;
    });

  // Calculate global debt summary across all customers
  const totalDebtsCount = customers.filter((c) => {
    const { netDebt } = getCustomerBalance(c.id, transactions);
    return netDebt > 0;
  }).length;

  const totalOutstandingDebt = customers.reduce((sum, c) => {
    const { netDebt } = getCustomerBalance(c.id, transactions);
    return sum + (netDebt > 0 ? netDebt : 0);
  }, 0);

  const handleSubmitNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    onAddCustomer({
      name: newName.trim(),
      phone: newPhone.trim(),
      notes: newNotes.trim(),
    });

    setNewName('');
    setNewPhone('');
    setNewNotes('');
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-3.5 pb-20">
      {/* Debt Summary Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-amber-600/5 to-slate-900 border border-amber-500/25 flex items-center justify-between">
        <div>
          <span className="text-xs text-slate-400 font-medium">إجمالي ديون العملاء بالسوق:</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-black text-rose-400 font-mono tabular-nums">
              {totalOutstandingDebt.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-slate-400">{settings.currency.symbol}</span>
          </div>
        </div>

        <div className="text-left text-xs bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-800">
          <span className="text-amber-400 font-bold font-mono">{totalDebtsCount}</span>
          <span className="text-slate-400 mr-1">عملاء بذمتهم ديون</span>
        </div>
      </div>

      {/* Action Strip: Search & Add */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5" />
          <input
            type="text"
            placeholder="ابحث باسم العميل أو رقم الهاتف..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-11 pr-10 pl-4 rounded-xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 text-xs focus:border-amber-400 focus:outline-none"
          />
        </div>

        <button
          onClick={handleImportContact}
          className="h-11 px-3 rounded-xl bg-slate-900 border border-slate-800 text-amber-400 hover:border-amber-500/40 font-bold text-xs flex items-center gap-1.5 shrink-0 active:scale-95 transition-transform"
          title="استيراد جهة اتصال من الهاتف"
        >
          <Contact className="w-4 h-4" />
          <span className="hidden xs:inline">جهات الاتصال</span>
        </button>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="h-11 px-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 shrink-0 active:scale-95 transition-transform"
        >
          <UserPlus className="w-4 h-4 stroke-[3]" />
          <span>عميل جديد</span>
        </button>
      </div>

      {/* Filter Tabs: Oldest First, Today, Past Week, Past Month, Newest First */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        <button
          onClick={() => setTimeFilter('newest')}
          className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
            timeFilter === 'newest'
              ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          الأحدث أولاً (تلقائي)
        </button>

        <button
          onClick={() => setTimeFilter('today')}
          className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
            timeFilter === 'today'
              ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          اليوم
        </button>

        <button
          onClick={() => setTimeFilter('week')}
          className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
            timeFilter === 'week'
              ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          الأسبوع الماضي
        </button>

        <button
          onClick={() => setTimeFilter('month')}
          className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
            timeFilter === 'month'
              ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          الشهر الماضي
        </button>

        <button
          onClick={() => setTimeFilter('oldest')}
          className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
            timeFilter === 'oldest'
              ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          الأقدم أولاً
        </button>
      </div>

      {/* Customer List Feed */}
      {filteredAndSortedCustomers.length === 0 ? (
        <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800/80 my-4">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-500/10 flex items-center justify-center text-amber-400 mb-2.5">
            <Users className="w-6 h-6" />
          </div>
          <h4 className="text-white font-bold text-sm mb-1">لا يوجد عملاء يطابقون الفلتر</h4>
          <p className="text-xs text-slate-400 mb-3">
            يمكنك إضافة عميل جديد يدوياً أو استيراده مباشرة من جهات اتصال هاتفك.
          </p>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs"
          >
            إضافة عميل الآن
          </button>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredAndSortedCustomers.map((cust) => {
            const { netDebt, transactionCount } = getCustomerBalance(cust.id, transactions);
            const isOwed = netDebt > 0;
            const isCredit = netDebt < 0;

            return (
              <div
                key={cust.id}
                onClick={() => onSelectCustomer(cust)}
                className="p-3.5 rounded-2xl bg-[#11131a] border border-slate-800/90 hover:border-amber-500/40 flex items-center justify-between gap-3 cursor-pointer active:scale-[0.99] transition-all group"
              >
                {/* Avatar and name */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 border ${
                    isOwed
                      ? 'bg-rose-500/15 border-rose-500/30 text-rose-300'
                      : isCredit
                      ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                      : 'bg-slate-800 border-slate-700 text-slate-300'
                  }`}>
                    {cust.name.slice(0, 1)}
                  </div>

                  <div className="min-w-0">
                    <h4 className="font-bold text-white text-xs sm:text-sm truncate group-hover:text-amber-300 transition-colors">
                      {cust.name}
                    </h4>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                      {cust.phone ? (
                        <span className="font-mono text-left" dir="ltr">{cust.phone}</span>
                      ) : (
                        <span>لا يوجد رقم</span>
                      )}
                      <span>·</span>
                      <span>{transactionCount} حركات</span>
                    </div>
                  </div>
                </div>

                {/* Balance display & chevron */}
                <div className="flex items-center gap-2.5 shrink-0">
                  <div className="text-left font-mono">
                    <div className={`text-sm sm:text-base font-extrabold tabular-nums ${
                      isOwed
                        ? 'text-rose-400'
                        : isCredit
                        ? 'text-emerald-400'
                        : 'text-slate-400'
                    }`}>
                      {Math.abs(netDebt).toLocaleString()} {settings.currency.symbol}
                    </div>
                    <div className={`text-[10px] font-medium ${
                      isOwed ? 'text-rose-400/90' : isCredit ? 'text-emerald-400/90' : 'text-slate-500'
                    }`}>
                      {isOwed ? 'مطلوب منه' : isCredit ? 'له رصيد' : 'خالص'}
                    </div>
                  </div>

                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:text-amber-400 group-hover:-translate-x-1 transition-all" />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add New Customer Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-sm bg-[#11131a] border border-amber-500/20 rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h4 className="font-bold text-white text-sm">تسجيل عميل جديد بالدفتر</h4>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitNew} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  اسم العميل <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="الاسم الكامل للعميل"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  رقم الهاتف (لرسائل وتذكيرات الواتساب)
                </label>
                <input
                  type="tel"
                  placeholder="مثال: 5312345678"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none font-mono text-left"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  ملاحظات أو العنوان
                </label>
                <input
                  type="text"
                  placeholder="حي الفاتح، تاجر جملة..."
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full h-12 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-400/20 active:scale-95 transition-transform"
                >
                  إضافة العميل والبدء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
