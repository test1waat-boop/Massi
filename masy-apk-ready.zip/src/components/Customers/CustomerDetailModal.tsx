import React, { useState, useRef } from 'react';
import { 
  X, 
  Send, 
  Clock, 
  Calculator, 
  Plus, 
  Minus, 
  Trash2, 
  MessageSquare, 
  Phone, 
  AlertTriangle,
  Receipt,
  Calendar,
  CheckCircle,
  FileText
} from 'lucide-react';
import { Customer, CustomerTransaction, StoreSettings, TransactionType } from '../../types';
import { getCustomerBalance } from '../../utils/storage';
import { generateAccountStatementText, generateDebtReminderText, openWhatsApp } from '../../utils/whatsapp';
import { CalculatorModal } from '../Common/CalculatorModal';

interface CustomerDetailModalProps {
  customer: Customer;
  transactions: CustomerTransaction[];
  settings: StoreSettings;
  isOpen: boolean;
  onClose: () => void;
  onAddTransaction: (customerId: string, type: TransactionType, amount: number, note: string) => void;
  onDeleteTransaction: (transactionId: string) => void;
  onDeleteCustomer: (customerId: string) => void;
}

export const CustomerDetailModal: React.FC<CustomerDetailModalProps> = ({
  customer,
  transactions,
  settings,
  isOpen,
  onClose,
  onAddTransaction,
  onDeleteTransaction,
  onDeleteCustomer,
}) => {
  // New transaction state
  const [txType, setTxType] = useState<TransactionType>('given');
  const [txAmount, setTxAmount] = useState<number>(0);
  const [txNote, setTxNote] = useState<string>('');
  const [isCalculatorOpen, setIsCalculatorOpen] = useState<boolean>(false);

  // Long press deletion for transactions
  const [deletingTxId, setDeletingTxId] = useState<string | null>(null);
  const [longPressProgressId, setLongPressProgressId] = useState<string | null>(null);
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Delete customer modal security confirmation
  const [isDeleteCustomerModalOpen, setIsDeleteCustomerModalOpen] = useState<boolean>(false);
  const [confirmationInput, setConfirmationInput] = useState<string>('');

  if (!isOpen) return null;

  const { totalGiven, totalTaken, netDebt, firstDebtDate } = getCustomerBalance(customer.id, transactions);
  const currency = settings.currency.symbol;

  const customerTxs = transactions
    .filter((t) => t.customerId === customer.id)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Calculate days passed since debt began
  let daysSinceDebtBegan = 0;
  if (firstDebtDate) {
    const diff = Date.now() - new Date(firstDebtDate).getTime();
    daysSinceDebtBegan = Math.max(1, Math.floor(diff / (1000 * 60 * 60 * 24)));
  }

  // Handle adding transaction
  const handleSaveTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (txAmount <= 0) {
      alert('يرجى تحديد مبلغ العملية');
      return;
    }
    onAddTransaction(customer.id, txType, txAmount, txNote.trim());
    setTxAmount(0);
    setTxNote('');

    // Tactile feedback
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try { navigator.vibrate(25); } catch {}
    }
  };

  // Long press handlers for transactions
  const handleTouchStart = (txId: string) => {
    setLongPressProgressId(txId);
    longPressTimerRef.current = setTimeout(() => {
      if (typeof window !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate(60); } catch {}
      }
      setDeletingTxId(txId);
      setLongPressProgressId(null);
    }, 700);
  };

  const handleTouchEnd = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    setLongPressProgressId(null);
  };

  // WhatsApp triggers
  const handleSendStatement = () => {
    const text = generateAccountStatementText(customer, transactions, settings);
    openWhatsApp(customer.phone, settings.countryCode, text);
  };

  const handleSendReminder = () => {
    const text = generateDebtReminderText(customer, transactions, settings);
    openWhatsApp(customer.phone, settings.countryCode, text);
  };

  const handleConfirmDeleteCustomer = () => {
    if (confirmationInput.trim() !== 'حذف') {
      alert('يرجى كتابة كلمة "حذف" للتأكيد');
      return;
    }
    onDeleteCustomer(customer.id);
    setIsDeleteCustomerModalOpen(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div 
        className="w-full max-w-lg bg-[#11131a] border border-amber-500/20 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[94vh] sm:max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-[#0d0e14]/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400/20 to-amber-600/20 border border-amber-400/30 flex items-center justify-center text-amber-300 font-extrabold text-lg">
              {customer.name.slice(0, 1)}
            </div>
            <div>
              <h3 className="font-extrabold text-white text-base leading-tight">{customer.name}</h3>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                {customer.phone && (
                  <span className="font-mono text-left" dir="ltr">
                    {customer.phone}
                  </span>
                )}
                {customer.notes && (
                  <>
                    <span>·</span>
                    <span className="truncate max-w-[150px]">{customer.notes}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsDeleteCustomerModalOpen(true)}
              className="w-9 h-9 rounded-full flex items-center justify-center bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition-colors"
              title="حذف العميل"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full flex items-center justify-center bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 space-y-4 overflow-y-auto flex-1">
          {/* Net Balance Card */}
          <div className={`p-4 rounded-2xl border ${
            netDebt > 0
              ? 'bg-rose-950/20 border-rose-500/30'
              : netDebt < 0
              ? 'bg-emerald-950/20 border-emerald-500/30'
              : 'bg-slate-900 border-slate-800'
          }`}>
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 font-medium">الرصيد الصافي المتبقي:</span>
                <div className="flex items-baseline gap-1.5 mt-1">
                  <span className={`text-3xl font-black font-mono tabular-nums ${
                    netDebt > 0 ? 'text-rose-400' : netDebt < 0 ? 'text-emerald-400' : 'text-slate-300'
                  }`}>
                    {Math.abs(netDebt).toLocaleString()}
                  </span>
                  <span className="text-sm font-bold text-slate-400">{currency}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-bold mr-2 ${
                    netDebt > 0
                      ? 'bg-rose-500/20 text-rose-300'
                      : netDebt < 0
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-slate-800 text-slate-400'
                  }`}>
                    {netDebt > 0 ? 'مطلوب منه (عليه)' : netDebt < 0 ? 'رصيد دائن (له)' : 'خالص'}
                  </span>
                </div>
              </div>

              {netDebt > 0 && daysSinceDebtBegan > 0 && (
                <div className="text-left text-xs bg-slate-900/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400">عمر الدين</div>
                  <div className="text-amber-400 font-bold font-mono">{daysSinceDebtBegan} يوم</div>
                </div>
              )}
            </div>

            {/* Quick summary strip */}
            <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-800/80 text-xs">
              <div className="flex items-center justify-between text-slate-300">
                <span>إجمالي المسحوبات (أعطيت):</span>
                <span className="font-bold text-rose-400 font-mono tabular-nums">{totalGiven} {currency}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>إجمالي المدفوعات (أخذت):</span>
                <span className="font-bold text-emerald-400 font-mono tabular-nums">{totalTaken} {currency}</span>
              </div>
            </div>
          </div>

          {/* WhatsApp Action Buttons Strip */}
          <div className="grid grid-cols-2 gap-2.5">
            {/* Account Statement */}
            <button
              onClick={handleSendStatement}
              className="h-11 rounded-xl bg-slate-900 border border-slate-800 hover:border-emerald-500/40 text-emerald-400 font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>كشف حساب بالواتساب</span>
            </button>

            {/* Exact Reminder Button */}
            <button
              onClick={handleSendReminder}
              disabled={netDebt <= 0}
              className="h-11 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 text-amber-400 font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
              title="يرسل فقط الرصيد المتبقي وعدد الأيام المنقضية"
            >
              <MessageSquare className="w-4 h-4 text-amber-400" />
              <span>تذكير بالدين (واتساب)</span>
            </button>
          </div>

          {/* Add Transaction Section */}
          <div className="p-4 rounded-2xl bg-[#0c0e14] border border-amber-500/20 space-y-3">
            <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              تسجيل حركة جديدة بالدفتر
            </span>

            {/* Type selector: Given vs Taken */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setTxType('given')}
                className={`h-10 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                  txType === 'given'
                    ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                    : 'bg-slate-900 text-slate-400 border border-slate-800'
                }`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>أعطيت (دين عليه)</span>
              </button>

              <button
                type="button"
                onClick={() => setTxType('taken')}
                className={`h-10 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                  txType === 'taken'
                    ? 'bg-emerald-500 text-slate-950 font-black shadow-md shadow-emerald-500/20'
                    : 'bg-slate-900 text-slate-400 border border-slate-800'
                }`}
              >
                <Minus className="w-3.5 h-3.5" />
                <span>أخذت (سداد منه)</span>
              </button>
            </div>

            {/* Amount input with Calculator button */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="number"
                  min="0"
                  step="any"
                  placeholder="المبلغ..."
                  value={txAmount || ''}
                  onChange={(e) => setTxAmount(parseFloat(e.target.value) || 0)}
                  className="w-full h-11 px-3.5 pl-8 rounded-xl bg-slate-900 border border-slate-800 text-white text-sm font-mono font-bold focus:border-amber-400 focus:outline-none"
                />
                <span className="absolute left-3 top-3 text-xs text-slate-400">{currency}</span>
              </div>

              {/* Calculator trigger */}
              <button
                type="button"
                onClick={() => setIsCalculatorOpen(true)}
                className="h-11 px-3.5 rounded-xl bg-amber-400 text-slate-950 hover:bg-amber-300 font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-transform shrink-0"
              >
                <Calculator className="w-4 h-4 stroke-[2.5]" />
                <span className="hidden xs:inline">الحاسبة</span>
              </button>
            </div>

            {/* Note input */}
            <input
              type="text"
              placeholder="بيان الحركة (مثال: قميص أبيض، سداد كاش...)"
              value={txNote}
              onChange={(e) => setTxNote(e.target.value)}
              className="w-full h-10 px-3.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs placeholder-slate-500 focus:border-amber-400 focus:outline-none"
            />

            <button
              type="button"
              onClick={handleSaveTransaction}
              className="w-full h-11 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 active:scale-95 transition-transform"
            >
              <span>حفظ الحركة في الدفتر</span>
            </button>
          </div>

          {/* Transactions Ledger List with Long-Press Delete hint */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400">سجل المعاملات السابقة ({customerTxs.length})</span>
              <span className="text-[10px] text-amber-400/80 font-medium">اضغط مطولاً لحذف أي حركة</span>
            </div>

            {customerTxs.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500 rounded-xl bg-slate-900/40 border border-slate-800">
                لا توجد حركات مسجلة لهذا العميل حتى الآن.
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {customerTxs.map((tx) => {
                  const isGiven = tx.type === 'given';
                  const isBeingPressed = longPressProgressId === tx.id;

                  return (
                    <div
                      key={tx.id}
                      onMouseDown={() => handleTouchStart(tx.id)}
                      onMouseUp={handleTouchEnd}
                      onMouseLeave={handleTouchEnd}
                      onTouchStart={() => handleTouchStart(tx.id)}
                      onTouchEnd={handleTouchEnd}
                      className={`relative select-none p-3 rounded-xl border flex items-center justify-between gap-3 transition-all cursor-pointer ${
                        isBeingPressed ? 'scale-[0.98] ring-2 ring-rose-500' : ''
                      } ${
                        isGiven
                          ? 'bg-rose-950/10 border-rose-500/20 hover:border-rose-500/40'
                          : 'bg-emerald-950/10 border-emerald-500/20 hover:border-emerald-500/40'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded ${
                            isGiven ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'
                          }`}>
                            {isGiven ? '🔴 أعطيت' : '🟢 أخذت'}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {new Date(tx.date).toLocaleDateString('ar-EG', {
                              year: 'numeric',
                              month: 'numeric',
                              day: 'numeric',
                            })}
                          </span>
                        </div>
                        {tx.note && (
                          <p className="text-xs text-slate-300 mt-1 truncate">{tx.note}</p>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="text-left font-mono">
                          <span className={`text-base font-bold tabular-nums ${
                            isGiven ? 'text-rose-400' : 'text-emerald-400'
                          }`}>
                            {isGiven ? '+' : '-'}{tx.amount}
                          </span>
                          <span className="text-[10px] text-slate-400 mr-1">{currency}</span>
                        </div>

                        {/* Direct delete button fallback */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setDeletingTxId(tx.id);
                          }}
                          className="w-7 h-7 rounded-lg bg-slate-800 text-slate-400 hover:text-rose-400 flex items-center justify-center text-xs"
                          title="حذف الحركة"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Interactive Calculator Popup */}
      <CalculatorModal
        isOpen={isCalculatorOpen}
        initialValue={txAmount}
        currencySymbol={currency}
        title="حاسبة الحركة المالية"
        onClose={() => setIsCalculatorOpen(false)}
        onConfirm={(val) => {
          setTxAmount(val);
          setIsCalculatorOpen(false);
        }}
      />

      {/* Long Press Delete Confirmation Dialog */}
      {deletingTxId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-xs bg-[#12141c] border border-rose-500/30 rounded-2xl p-5 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-400 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-white text-sm mb-1">حذف حركة الدفتر</h4>
            <p className="text-xs text-slate-400 mb-4">
              هل أنت متأكد من حذف هذه الحركة المالية نهائياً وتحديث الرصيد؟
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setDeletingTxId(null)}
                className="flex-1 h-10 rounded-xl bg-slate-800 text-slate-300 font-semibold text-xs"
              >
                إلغاء
              </button>
              <button
                onClick={() => {
                  onDeleteTransaction(deletingTxId);
                  setDeletingTxId(null);
                }}
                className="flex-1 h-10 rounded-xl bg-rose-600 text-white font-bold text-xs"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Customer Security Confirmation Modal */}
      {isDeleteCustomerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm bg-[#12141c] border border-rose-500/40 rounded-3xl p-6 text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-rose-500/10 text-rose-400 flex items-center justify-center mx-auto border border-rose-500/20">
              <AlertTriangle className="w-7 h-7" />
            </div>
            <div>
              <h4 className="font-extrabold text-white text-base mb-1">
                تأكيد أمان حذف العميل: {customer.name}
              </h4>
              <p className="text-xs text-rose-300/90 leading-relaxed">
                حذف العميل سيؤدي إلى مسح سجله المالي وجميع ديونه المسجلة ولا يمكن التراجع عن هذه الخطوة!
              </p>
            </div>

            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300 text-right space-y-1.5">
              <p>للمتابعة، يرجى كتابة كلمة <span className="font-bold text-rose-400 font-mono">حذف</span> في المربع أدناه:</p>
              <input
                type="text"
                placeholder="اكتب: حذف"
                value={confirmationInput}
                onChange={(e) => setConfirmationInput(e.target.value)}
                className="w-full h-11 px-3 text-center rounded-xl bg-slate-950 border border-slate-700 text-white text-sm font-bold focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setIsDeleteCustomerModalOpen(false);
                  setConfirmationInput('');
                }}
                className="flex-1 h-11 rounded-xl bg-slate-800 text-slate-300 font-semibold text-xs"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={confirmationInput.trim() !== 'حذف'}
                onClick={handleConfirmDeleteCustomer}
                className="flex-1 h-11 rounded-xl bg-rose-600 text-white font-extrabold text-xs disabled:opacity-30 disabled:cursor-not-allowed hover:bg-rose-500 transition-colors"
              >
                حذف العميل نهائياً
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
