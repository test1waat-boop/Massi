import React, { useState } from 'react';
import {
  ShoppingBag,
  Search,
  CreditCard,
  Banknote,
  UserCheck,
  Contact,
  Plus,
  Minus,
  Trash2,
  CheckCircle2,
  X,
  ArrowRight,
  Check,
  SlidersHorizontal,
  RotateCcw,
  Receipt,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { InventoryItem, Customer, SaleRecord, SaleItem } from '../../types';
import { isContactsApiSupported, pickDeviceContact } from '../../utils/contacts';

interface QuickSalesProps {
  items: InventoryItem[];
  customers: Customer[];
  currencySymbol: string;
  onCompleteSale: (sale: SaleRecord, newCustomer?: { name: string; phone: string }) => void;
  onAddNewCustomer?: (name: string, phone: string) => Customer;
}

interface CartItem extends SaleItem {
  maxStock: number;
  image?: string | null;
}

export const QuickSales: React.FC<QuickSalesProps> = ({
  items,
  customers,
  currencySymbol,
  onCompleteSale,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [paymentType, setPaymentType] = useState<'cash' | 'credit'>('cash');

  // Credit customer selection
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [manualCustomerName, setManualCustomerName] = useState<string>('');
  const [manualCustomerPhone, setManualCustomerPhone] = useState<string>('');
  const [isNewCustomerMode, setIsNewCustomerMode] = useState<boolean>(false);
  const [contactPickerError, setContactPickerError] = useState<string | null>(null);

  // Variant customizer modal for specific item
  const [customizingItem, setCustomizingItem] = useState<InventoryItem | null>(null);
  const [customColor, setCustomColor] = useState<string>('');
  const [customSize, setCustomSize] = useState<string>('');

  // Extract categories
  const categories = ['all', ...Array.from(new Set(items.map((i) => i.category || 'عام')))];

  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.colors.some((c) => c.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (item.category && item.category.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = selectedCategory === 'all' || (item.category || 'عام') === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Dynamic invoice totals calculated live from selected products
  const cartTotal = cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const cartCostTotal = cart.reduce((sum, item) => sum + item.unitCost * item.quantity, 0);
  const cartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const distinctSelectedItemsCount = new Set(cart.map((c) => c.itemId)).size;

  const triggerHaptic = () => {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(15);
      } catch {}
    }
  };

  /**
   * Multi-select toggle on card tap:
   * - Tap unselected item -> selects it (adds 1 unit) and shows the Blue Checkmark in top corner
   * - Tap selected item -> deselects it and removes it from the invoice
   */
  const handleToggleSelectItem = (item: InventoryItem) => {
    if (item.stockQuantity <= 0) return;
    triggerHaptic();

    setCart((prev) => {
      const isAlreadySelected = prev.some((c) => c.itemId === item.id);
      if (isAlreadySelected) {
        return prev.filter((c) => c.itemId !== item.id);
      }

      return [
        ...prev,
        {
          itemId: item.id,
          itemName: item.name,
          color: item.colors[0] || '',
          size: item.sizes[0] || '',
          quantity: 1,
          unitPrice: item.sellingPrice,
          unitCost: item.costPrice,
          maxStock: item.stockQuantity,
          image: item.image,
        },
      ];
    });
  };

  /**
   * Adjust quantity directly on a selected card (+/-) without toggling selection off unless qty hits 0
   */
  const handleCardQuantityChange = (
    itemId: string,
    delta: number,
    maxStock: number,
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    triggerHaptic();

    setCart((prev) => {
      const index = prev.findIndex((c) => c.itemId === itemId);
      if (index === -1) return prev;

      const current = prev[index];
      const newQty = current.quantity + delta;

      if (newQty <= 0) {
        return prev.filter((c) => c.itemId !== itemId);
      }

      if (newQty <= maxStock) {
        const next = [...prev];
        next[index] = { ...current, quantity: newQty };
        return next;
      }

      return prev;
    });
  };

  const handleUpdateCartIndexQty = (index: number, delta: number) => {
    triggerHaptic();
    setCart((prev) => {
      const target = prev[index];
      if (!target) return prev;
      const newQty = target.quantity + delta;
      if (newQty <= 0) {
        return prev.filter((_, i) => i !== index);
      }
      if (newQty <= target.maxStock) {
        const next = [...prev];
        next[index] = { ...target, quantity: newQty };
        return next;
      }
      return prev;
    });
  };

  const handleRemoveCartIndex = (index: number) => {
    triggerHaptic();
    setCart((prev) => prev.filter((_, i) => i !== index));
  };

  const handleClearAllSelection = () => {
    triggerHaptic();
    setCart([]);
  };

  // Variant selector
  const handleOpenCustomizer = (item: InventoryItem, e: React.MouseEvent) => {
    e.stopPropagation();
    setCustomizingItem(item);
    const existing = cart.find((c) => c.itemId === item.id);
    setCustomColor(existing?.color || item.colors[0] || '');
    setCustomSize(existing?.size || item.sizes[0] || '');
  };

  const handleSaveCustomVariant = () => {
    if (!customizingItem) return;
    setCart((prev) => {
      const existingIndex = prev.findIndex((c) => c.itemId === customizingItem.id);
      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          color: customColor,
          size: customSize,
        };
        return next;
      }
      return [
        ...prev,
        {
          itemId: customizingItem.id,
          itemName: customizingItem.name,
          color: customColor,
          size: customSize,
          quantity: 1,
          unitPrice: customizingItem.sellingPrice,
          unitCost: customizingItem.costPrice,
          maxStock: customizingItem.stockQuantity,
          image: customizingItem.image,
        },
      ];
    });
    setCustomizingItem(null);
  };

  // Contacts API
  const handlePickFromContacts = async () => {
    setContactPickerError(null);
    try {
      const contact = await pickDeviceContact();
      if (contact && contact.name) {
        setManualCustomerName(contact.name);
        setManualCustomerPhone(contact.phone || '');
        setIsNewCustomerMode(true);
        setSelectedCustomerId('');
      } else {
        if (!isContactsApiSupported()) {
          setContactPickerError('خاصية جهات الاتصال غير مدعومة في هذا المتصفح، يمكنك إدخال الاسم يدوياً.');
        }
      }
    } catch {
      setContactPickerError('تعذر جلب جهة الاتصال، يرجى كتابة الاسم ورقم الهاتف.');
    }
  };

  const handleFinalizeSale = () => {
    if (cart.length === 0) return;

    let finalCustomerId: string | undefined = undefined;
    let finalCustomerName: string | undefined = undefined;
    let newCust: { name: string; phone: string } | undefined = undefined;

    if (paymentType === 'credit') {
      if (isNewCustomerMode || !selectedCustomerId) {
        if (!manualCustomerName.trim()) {
          alert('يرجى تحديد اسم العميل لتسجيل البيع بالدين.');
          return;
        }
        newCust = {
          name: manualCustomerName.trim(),
          phone: manualCustomerPhone.trim(),
        };
        finalCustomerName = newCust.name;
      } else {
        const found = customers.find((c) => c.id === selectedCustomerId);
        if (!found) {
          alert('يرجى اختيار العميل');
          return;
        }
        finalCustomerId = found.id;
        finalCustomerName = found.name;
      }
    }

    const saleRecord: SaleRecord = {
      id: `sale-${Date.now()}`,
      date: new Date().toISOString(),
      items: cart.map((c) => ({
        itemId: c.itemId,
        itemName: c.itemName,
        color: c.color,
        size: c.size,
        quantity: c.quantity,
        unitPrice: c.unitPrice,
        unitCost: c.unitCost,
      })),
      totalAmount: cartTotal,
      totalCost: cartCostTotal,
      paymentType,
      customerId: finalCustomerId,
      customerName: finalCustomerName,
    };

    onCompleteSale(saleRecord, newCust);

    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#2563EB', '#D4AF37', '#10B981'],
      });
    } catch {}

    setCart([]);
    setIsCheckoutOpen(false);
    setSelectedCustomerId('');
    setManualCustomerName('');
    setManualCustomerPhone('');
  };

  return (
    <div className="space-y-3 pb-28">
      {/* Top Search & Filter Bar */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5" />
          <input
            type="text"
            placeholder="ابحث بالاسم لتحديد عدة منتجات في فاتورة واحدة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-11 pr-10 pl-4 rounded-xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 text-xs focus:border-blue-500 focus:outline-none"
          />
        </div>

        {/* Categories Bar */}
        {categories.length > 2 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {cat === 'all' ? 'جميع الأصناف' : cat}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Live Multi-Selection & Dynamic Invoice Strip */}
      <div className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-2 ${
        distinctSelectedItemsCount > 0
          ? 'bg-blue-950/30 border-blue-500/40'
          : 'bg-slate-900/60 border-slate-800/80'
      }`}>
        <div className="flex items-center gap-2 min-w-0">
          <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
            distinctSelectedItemsCount > 0 ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
          }`}>
            <Receipt className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            {distinctSelectedItemsCount > 0 ? (
              <>
                <div className="text-xs font-bold text-blue-200 truncate">
                  {distinctSelectedItemsCount} منتجات محددة ({cartItemsCount} قطعة)
                </div>
                <div className="text-[11px] text-blue-400 font-mono font-bold tabular-nums">
                  إجمالي الفاتورة: {cartTotal.toLocaleString()} {currencySymbol}
                </div>
              </>
            ) : (
              <>
                <div className="text-xs font-semibold text-slate-200">تحديد متعدد للمنتجات</div>
                <div className="text-[11px] text-slate-400">اضغط على المنتجات لإضافتها أو إلغائها</div>
              </>
            )}
          </div>
        </div>

        {distinctSelectedItemsCount > 0 && (
          <button
            type="button"
            onClick={handleClearAllSelection}
            className="px-2.5 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:text-rose-300 flex items-center gap-1 text-xs font-semibold shrink-0 active:scale-95 transition-transform"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>إفراغ</span>
          </button>
        )}
      </div>

      {/* Products Grid with Blue Checkmark in Upper Corner */}
      <div className="grid grid-cols-2 xs:grid-cols-3 gap-2.5">
        {filteredItems.map((item) => {
          const isOutOfStock = item.stockQuantity <= 0;
          const cartItem = cart.find((c) => c.itemId === item.id);
          const isSelected = !!cartItem;
          const selectedQty = cartItem ? cartItem.quantity : 0;

          return (
            <div
              key={item.id}
              onClick={() => handleToggleSelectItem(item)}
              className={`rounded-2xl p-2 flex flex-col justify-between transition-all cursor-pointer relative select-none ${
                isOutOfStock
                  ? 'bg-slate-900/40 border border-slate-800/50 opacity-40 cursor-not-allowed'
                  : isSelected
                  ? 'bg-[#0f172a] border-2 border-blue-500 shadow-lg shadow-blue-500/20 ring-2 ring-blue-500/25'
                  : 'bg-[#11131a] border border-slate-800/90 hover:border-slate-700 active:scale-[0.98]'
              }`}
            >
              {/* --- BLUE CHECKMARK IN UPPER CORNER (إشارة زرقاء في الزاوية العلوية) --- */}
              {!isOutOfStock && (
                <div
                  className="absolute top-2 right-2 z-20"
                  aria-label={isSelected ? 'منتج محدد' : 'تحديد المنتج'}
                >
                  {isSelected ? (
                    <div className="w-7 h-7 rounded-full bg-blue-500 text-white flex items-center justify-center shadow-lg shadow-blue-500/50 border-2 border-white/90 animate-in zoom-in-75 duration-150">
                      <Check className="w-4 h-4 stroke-[3.5]" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full border-2 border-slate-600/80 bg-black/45 backdrop-blur-sm flex items-center justify-center hover:border-blue-400 transition-colors" />
                  )}
                </div>
              )}

              {/* Stock count badge (top-left upper corner) */}
              <div className="absolute top-2 left-2 z-10">
                <span
                  className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded shadow-sm ${
                    isOutOfStock
                      ? 'bg-rose-500 text-white'
                      : isSelected
                      ? 'bg-blue-950/90 text-blue-200 border border-blue-500/40'
                      : 'bg-black/70 text-slate-300 backdrop-blur-sm'
                  }`}
                >
                  {isOutOfStock ? 'نفد' : `${item.stockQuantity} ق`}
                </span>
              </div>

              {/* Product Thumbnail */}
              <div className="aspect-square w-full rounded-xl bg-slate-950 overflow-hidden relative mb-2 flex items-center justify-center">
                {item.image ? (
                  <img
                    src={item.image}
                    alt={item.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <ShoppingBag
                    className={`w-8 h-8 ${isSelected ? 'text-blue-400/80' : 'text-amber-400/40'}`}
                  />
                )}
              </div>

              {/* Product Info */}
              <div>
                <h4
                  className={`font-bold text-xs line-clamp-1 transition-colors ${
                    isSelected ? 'text-blue-200' : 'text-white'
                  }`}
                >
                  {item.name}
                </h4>

                <div className="flex items-baseline justify-between mt-1">
                  <span
                    className={`text-sm font-extrabold font-mono tabular-nums ${
                      isSelected ? 'text-blue-400' : 'text-amber-300'
                    }`}
                  >
                    {item.sellingPrice} {currencySymbol}
                  </span>

                  {(item.sizes.length > 1 || item.colors.length > 1) && (
                    <button
                      type="button"
                      onClick={(e) => handleOpenCustomizer(item, e)}
                      className="text-[10px] text-slate-400 hover:text-blue-400 flex items-center gap-0.5 py-0.5 px-1.5 rounded bg-slate-800/80"
                      title="تغيير اللون أو المقاس"
                    >
                      <SlidersHorizontal className="w-2.5 h-2.5" />
                      <span>خصائص</span>
                    </button>
                  )}
                </div>

                {/* Selected Variant Summary + Inline +/- Quantity Controls */}
                {isSelected && (
                  <div className="mt-2 space-y-1.5">
                    {(cartItem.color || cartItem.size) && (
                      <div className="text-[10px] text-blue-300/80 truncate px-0.5">
                        {[cartItem.color, cartItem.size].filter(Boolean).join(' · ')}
                      </div>
                    )}
                    <div className="flex items-center justify-between pt-1.5 border-t border-blue-500/25 bg-blue-950/40 rounded-xl px-1.5 py-1">
                      <button
                        type="button"
                        onClick={(e) => handleCardQuantityChange(item.id, -1, item.stockQuantity, e)}
                        className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-200 hover:bg-blue-600 hover:text-white flex items-center justify-center active:scale-90 transition-all"
                        aria-label="تقليل الكمية"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>

                      <span className="text-xs font-mono font-bold text-blue-100 tabular-nums">
                        {selectedQty} × {item.sellingPrice}
                      </span>

                      <button
                        type="button"
                        onClick={(e) => handleCardQuantityChange(item.id, 1, item.stockQuantity, e)}
                        disabled={selectedQty >= item.stockQuantity}
                        className="w-7 h-7 rounded-lg bg-blue-600 text-white hover:bg-blue-500 flex items-center justify-center disabled:opacity-30 active:scale-90 transition-all"
                        aria-label="زيادة الكمية"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating Bottom Bar with Live Dynamic Invoice Total */}
      {cart.length > 0 && (
        <div className="fixed bottom-16 left-0 right-0 z-30 p-3 bg-gradient-to-t from-[#08090d] via-[#08090d]/95 to-transparent">
          <div className="max-w-md mx-auto">
            <button
              onClick={() => setIsCheckoutOpen(true)}
              className="w-full h-14 rounded-2xl bg-gradient-to-r from-blue-600 via-blue-500 to-blue-600 text-white font-black text-sm flex items-center justify-between px-5 shadow-xl shadow-blue-600/30 border border-blue-400/40 active:scale-[0.98] transition-transform"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-white text-blue-700 flex items-center justify-center font-mono font-black text-xs shadow-md tabular-nums">
                  {cartItemsCount}
                </div>
                <div className="text-right">
                  <div className="leading-tight text-white font-extrabold">إتمام الفاتورة</div>
                  <div className="text-[11px] text-blue-100 font-normal">
                    {distinctSelectedItemsCount} أصناف مختارة ({cartItemsCount} قطعة)
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-base font-extrabold font-mono tabular-nums">
                  {cartTotal.toLocaleString()} {currencySymbol}
                </span>
                <ArrowRight className="w-5 h-5 stroke-[3] rotate-180" />
              </div>
            </button>
          </div>
        </div>
      )}

      {/* Variant Customizer Modal */}
      {customizingItem && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm bg-[#11131a] border border-blue-500/40 rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="font-bold text-white text-sm">{customizingItem.name}</h4>
                <p className="text-xs text-blue-400 font-mono font-bold mt-0.5 tabular-nums">
                  {customizingItem.sellingPrice} {currencySymbol}
                </p>
              </div>
              <button
                onClick={() => setCustomizingItem(null)}
                className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Colors */}
            {customizingItem.colors.length > 0 && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">اختر اللون المحدد</label>
                <div className="flex flex-wrap gap-1.5">
                  {customizingItem.colors.map((c) => (
                    <button
                      key={c}
                      onClick={() => setCustomColor(c)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors ${
                        customColor === c
                          ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                          : 'bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Sizes */}
            {customizingItem.sizes.length > 0 && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">اختر المقاس المحدد</label>
                <div className="flex flex-wrap gap-1.5">
                  {customizingItem.sizes.map((s) => (
                    <button
                      key={s}
                      onClick={() => setCustomSize(s)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-mono font-medium transition-colors ${
                        customSize === s
                          ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                          : 'bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={handleSaveCustomVariant}
              className="w-full h-12 rounded-xl bg-blue-600 text-white font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-lg shadow-blue-600/20"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              تأكيد الخيارات والتحديد
            </button>
          </div>
        </div>
      )}

      {/* Checkout Drawer / Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-md bg-[#11131a] border border-blue-500/30 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#0d0e14]/70">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-blue-400" />
                <h3 className="font-extrabold text-white text-base">إتمام الفاتورة للمنتجات المحددة</h3>
              </div>
              <button
                onClick={() => setIsCheckoutOpen(false)}
                className="w-9 h-9 rounded-full flex items-center justify-center bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-5 space-y-4 overflow-y-auto flex-1">
              {/* Selected Items List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>المنتجات المختارة ({cart.length}):</span>
                  <span>الكمية والسعر</span>
                </div>
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {cart.map((item, idx) => (
                    <div
                      key={`${item.itemId}-${item.color}-${item.size}`}
                      className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0 flex-1">
                        <h5 className="font-bold text-white text-xs truncate">{item.itemName}</h5>
                        <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mt-0.5">
                          {item.color && <span>{item.color}</span>}
                          {item.size && <span>({item.size})</span>}
                          <span>·</span>
                          <span className="text-blue-300 font-mono tabular-nums">
                            {(item.unitPrice * item.quantity).toLocaleString()} {currencySymbol}
                          </span>
                        </div>
                      </div>

                      {/* Qty controls */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => handleUpdateCartIndexQty(idx, -1)}
                          className="w-7 h-7 rounded-md bg-slate-800 text-slate-300 hover:bg-slate-700 flex items-center justify-center font-bold text-xs"
                        >
                          -
                        </button>
                        <span className="w-6 text-center font-mono font-bold text-xs text-white tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => handleUpdateCartIndexQty(idx, 1)}
                          disabled={item.quantity >= item.maxStock}
                          className="w-7 h-7 rounded-md bg-slate-800 text-slate-300 hover:bg-slate-700 flex items-center justify-center font-bold text-xs disabled:opacity-30"
                        >
                          +
                        </button>
                        <button
                          onClick={() => handleRemoveCartIndex(idx)}
                          className="w-7 h-7 rounded-md bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 flex items-center justify-center text-xs mr-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total Summary */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-950/40 via-slate-900 to-slate-900 border border-blue-500/30 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400">إجمالي الفاتورة:</span>
                  <div className="text-2xl font-black text-blue-400 font-mono tabular-nums">
                    {cartTotal.toLocaleString()} <span className="text-sm font-semibold">{currencySymbol}</span>
                  </div>
                </div>
                <div className="text-left text-xs text-emerald-400 font-medium font-mono tabular-nums">
                  ربح الفاتورة: +{(cartTotal - cartCostTotal).toLocaleString()} {currencySymbol}
                </div>
              </div>

              {/* Payment Type Switcher: Cash vs Credit */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">طريقة الدفع</label>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setPaymentType('cash')}
                    className={`h-12 rounded-xl flex items-center justify-center gap-2 font-bold text-xs transition-all ${
                      paymentType === 'cash'
                        ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20 scale-[1.02]'
                        : 'bg-slate-900 text-slate-400 border border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <Banknote className="w-4 h-4 stroke-[2.5]" />
                    <span>نقداً (كاش)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentType('credit')}
                    className={`h-12 rounded-xl flex items-center justify-center gap-2 font-bold text-xs transition-all ${
                      paymentType === 'credit'
                        ? 'bg-amber-400 text-slate-950 shadow-lg shadow-amber-400/20 scale-[1.02]'
                        : 'bg-slate-900 text-slate-400 border border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 stroke-[2.5]" />
                    <span>بالدين (آجل)</span>
                  </button>
                </div>
              </div>

              {/* Credit Customer Selector & Device Contacts Picker */}
              {paymentType === 'credit' && (
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                      <UserCheck className="w-4 h-4" />
                      تحديد العميل للذمة المالية
                    </span>

                    {/* Contacts API Trigger */}
                    <button
                      type="button"
                      onClick={handlePickFromContacts}
                      className="px-2.5 py-1 rounded-lg bg-amber-400 text-slate-950 font-bold text-[11px] flex items-center gap-1 hover:bg-amber-300 active:scale-95 transition-transform"
                    >
                      <Contact className="w-3.5 h-3.5" />
                      استيراد من جهات الاتصال
                    </button>
                  </div>

                  {contactPickerError && (
                    <p className="text-[11px] text-amber-300/80 leading-tight">{contactPickerError}</p>
                  )}

                  {/* Mode switch: existing vs new */}
                  <div className="flex gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setIsNewCustomerMode(false)}
                      className={`flex-1 py-1.5 rounded-lg font-medium transition-colors ${
                        !isNewCustomerMode ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-slate-900 text-slate-400'
                      }`}
                    >
                      عميل مسجل مسبقاً
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsNewCustomerMode(true);
                        setSelectedCustomerId('');
                      }}
                      className={`flex-1 py-1.5 rounded-lg font-medium transition-colors ${
                        isNewCustomerMode ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-slate-900 text-slate-400'
                      }`}
                    >
                      عميل جديد
                    </button>
                  </div>

                  {!isNewCustomerMode ? (
                    <div>
                      <select
                        value={selectedCustomerId}
                        onChange={(e) => setSelectedCustomerId(e.target.value)}
                        className="w-full h-11 px-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none"
                      >
                        <option value="">-- اختر من قائمة العملاء المسجلين --</option>
                        {customers.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name} {c.phone ? `(${c.phone})` : ''}
                          </option>
                        ))}
                      </select>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <input
                        type="text"
                        placeholder="اسم العميل (مطلوب)"
                        value={manualCustomerName}
                        onChange={(e) => setManualCustomerName(e.target.value)}
                        className="w-full h-10 px-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none"
                      />
                      <input
                        type="tel"
                        placeholder="رقم الهاتف (للواتساب)"
                        value={manualCustomerPhone}
                        onChange={(e) => setManualCustomerPhone(e.target.value)}
                        className="w-full h-10 px-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none font-mono text-left"
                        dir="ltr"
                      />
                    </div>
                  )}

                  <p className="text-[11px] text-slate-400">
                    سيتم ترحيل مبلغ الفاتورة تلقائياً إلى دفتر ديون العميل كحركة "أعطيت".
                  </p>
                </div>
              )}
            </div>

            {/* Action Bar */}
            <div className="p-4 bg-[#11131a] border-t border-slate-800">
              <button
                onClick={handleFinalizeSale}
                className="w-full h-13 rounded-2xl bg-gradient-to-r from-blue-600 to-blue-500 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 active:scale-[0.98] transition-transform"
              >
                <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                <span>تأكيد العملية ({cartTotal.toLocaleString()} {currencySymbol})</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
