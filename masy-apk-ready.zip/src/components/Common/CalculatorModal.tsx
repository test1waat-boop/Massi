import React, { useState, useEffect, useCallback } from 'react';
import { X, Check, Delete } from 'lucide-react';

interface CalculatorModalProps {
  isOpen: boolean;
  initialValue?: number;
  currencySymbol?: string;
  onClose: () => void;
  onConfirm: (amount: number) => void;
  title?: string;
}

export const CalculatorModal: React.FC<CalculatorModalProps> = ({
  isOpen,
  initialValue = 0,
  currencySymbol = '₺',
  onClose,
  onConfirm,
  title = 'الحاسبة الذكية',
}) => {
  const [expression, setExpression] = useState<string>('');
  const [result, setResult] = useState<string>('0');

  useEffect(() => {
    if (isOpen) {
      if (initialValue > 0) {
        setExpression(initialValue.toString());
        setResult(initialValue.toString());
      } else {
        setExpression('');
        setResult('0');
      }
    }
  }, [isOpen, initialValue]);

  // Safe arithmetic evaluator
  const evaluateExpression = useCallback((expr: string): string => {
    try {
      if (!expr || expr.trim() === '') return '0';
      // replace display operators with js operators
      const sanitized = expr
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/[^-()\d/*+.]/g, '');
      
      if (!sanitized) return '0';
      // Evaluate using Function constructor safely without outer scope
      // eslint-disable-next-line no-new-func
      const val = new Function(`'use strict'; return (${sanitized})`)();
      if (typeof val === 'number' && !isNaN(val) && isFinite(val)) {
        return Math.round(val * 100) / 100 + '';
      }
      return '0';
    } catch {
      return result;
    }
  }, [result]);

  const triggerHaptic = () => {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(15);
      } catch {
        // ignore
      }
    }
  };

  const handleInput = (val: string) => {
    triggerHaptic();
    setExpression((prev) => {
      // Prevent consecutive operators
      const isOperator = ['+', '-', '×', '÷'].includes(val);
      const lastChar = prev.slice(-1);
      const isLastOperator = ['+', '-', '×', '÷'].includes(lastChar);

      let next = '';
      if (isOperator && isLastOperator) {
        next = prev.slice(0, -1) + val;
      } else if (prev === '0' && !isOperator && val !== '.') {
        next = val;
      } else {
        next = prev + val;
      }

      // calculate preview
      const preview = evaluateExpression(next);
      setResult(preview);
      return next;
    });
  };

  const handleClear = () => {
    triggerHaptic();
    setExpression('');
    setResult('0');
  };

  const handleDelete = () => {
    triggerHaptic();
    setExpression((prev) => {
      const next = prev.slice(0, -1);
      const preview = evaluateExpression(next);
      setResult(preview);
      return next;
    });
  };

  const handleEquals = () => {
    triggerHaptic();
    const finalVal = evaluateExpression(expression);
    setExpression(finalVal);
    setResult(finalVal);
  };

  const handleConfirm = () => {
    triggerHaptic();
    const finalVal = evaluateExpression(expression || result);
    const num = parseFloat(finalVal) || 0;
    onConfirm(Math.max(0, num));
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-[#11131a] border border-amber-500/20 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800/80 bg-slate-900/40">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <h3 className="font-bold text-slate-100 text-base">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Display Screen */}
        <div className="p-5 bg-gradient-to-b from-[#090a0e] to-[#12141c] border-b border-slate-800/80 text-left" dir="ltr">
          <div className="text-xs text-amber-400/80 font-mono tracking-wider h-5 overflow-x-auto whitespace-nowrap">
            {expression || '0'}
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-sm font-semibold text-slate-400">{currencySymbol}</span>
            <div className="text-3xl sm:text-4xl font-extrabold text-amber-300 font-mono tracking-tight tabular-nums">
              {result}
            </div>
          </div>
        </div>

        {/* Keypad */}
        <div className="p-4 bg-[#11131a] grid grid-cols-4 gap-2.5" dir="ltr">
          {/* Row 1 */}
          <button
            onClick={handleClear}
            className="h-13 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-400 font-bold text-lg active:scale-95 transition-all flex items-center justify-center"
          >
            C
          </button>
          <button
            onClick={() => handleInput('÷')}
            className="h-13 rounded-2xl bg-slate-800/80 border border-slate-700/60 text-amber-400 font-bold text-xl active:scale-95 transition-all flex items-center justify-center"
          >
            ÷
          </button>
          <button
            onClick={() => handleInput('×')}
            className="h-13 rounded-2xl bg-slate-800/80 border border-slate-700/60 text-amber-400 font-bold text-xl active:scale-95 transition-all flex items-center justify-center"
          >
            ×
          </button>
          <button
            onClick={handleDelete}
            className="h-13 rounded-2xl bg-slate-800/80 border border-slate-700/60 text-slate-300 font-bold text-lg active:scale-95 transition-all flex items-center justify-center"
          >
            <Delete className="w-5 h-5" />
          </button>

          {/* Row 2 */}
          <button
            onClick={() => handleInput('7')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            7
          </button>
          <button
            onClick={() => handleInput('8')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            8
          </button>
          <button
            onClick={() => handleInput('9')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            9
          </button>
          <button
            onClick={() => handleInput('-')}
            className="h-13 rounded-2xl bg-slate-800/80 border border-slate-700/60 text-amber-400 font-bold text-2xl active:scale-95 transition-all flex items-center justify-center"
          >
            -
          </button>

          {/* Row 3 */}
          <button
            onClick={() => handleInput('4')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            4
          </button>
          <button
            onClick={() => handleInput('5')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            5
          </button>
          <button
            onClick={() => handleInput('6')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            6
          </button>
          <button
            onClick={() => handleInput('+')}
            className="h-13 rounded-2xl bg-slate-800/80 border border-slate-700/60 text-amber-400 font-bold text-xl active:scale-95 transition-all flex items-center justify-center"
          >
            +
          </button>

          {/* Row 4 */}
          <button
            onClick={() => handleInput('1')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            1
          </button>
          <button
            onClick={() => handleInput('2')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            2
          </button>
          <button
            onClick={() => handleInput('3')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            3
          </button>
          <button
            onClick={handleEquals}
            className="h-13 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-xl active:scale-95 transition-all flex items-center justify-center"
          >
            =
          </button>

          {/* Row 5 */}
          <button
            onClick={() => handleInput('0')}
            className="col-span-2 h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            0
          </button>
          <button
            onClick={() => handleInput('.')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-xl active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            .
          </button>
          <button
            onClick={() => handleInput('00')}
            className="h-13 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-lg active:scale-95 transition-all flex items-center justify-center hover:bg-slate-850"
          >
            00
          </button>
        </div>

        {/* Action Button */}
        <div className="p-4 pt-2 pb-safe bg-[#11131a] border-t border-slate-800/80">
          <button
            onClick={handleConfirm}
            className="w-full h-13 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-base flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-[0.98] transition-transform"
          >
            <Check className="w-5 h-5 stroke-[3]" />
            <span>تأكيد المبلغ ({result} {currencySymbol})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
