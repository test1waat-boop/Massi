import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Package, 
  DollarSign, 
  Banknote, 
  CreditCard, 
  Coins, 
  Sparkles,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { InventoryItem, Customer, CustomerTransaction, SaleRecord, StoreSettings } from '../../types';
import { getCustomerBalance } from '../../utils/storage';

interface AnalyticsViewProps {
  inventory: InventoryItem[];
  customers: Customer[];
  transactions: CustomerTransaction[];
  sales: SaleRecord[];
  settings: StoreSettings;
}

type SalesTimeFilter = 'today' | 'yesterday' | 'week' | 'month' | 'all';

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  inventory,
  customers,
  transactions,
  sales,
  settings,
}) => {
  const [timeFilter, setTimeFilter] = useState<SalesTimeFilter>('today');
  const currency = settings.currency.symbol;

  // Inventory metrics
  const totalItemTypes = inventory.length;
  const totalStockUnits = inventory.reduce((sum, item) => sum + (Number(item.stockQuantity) || 0), 0);
  
  const totalInventoryCost = inventory.reduce(
    (sum, item) => sum + (Number(item.costPrice) || 0) * (Number(item.stockQuantity) || 0),
    0
  );

  const totalPotentialRevenue = inventory.reduce(
    (sum, item) => sum + (Number(item.sellingPrice) || 0) * (Number(item.stockQuantity) || 0),
    0
  );

  const totalPotentialProfit = Math.max(0, totalPotentialRevenue - totalInventoryCost);

  // Time-filtered sales metrics
  const filteredSales = sales.filter((sale) => {
    if (timeFilter === 'all') return true;

    const saleDate = new Date(sale.date);
    const now = new Date();
    const dayMs = 24 * 60 * 60 * 1000;

    if (timeFilter === 'today') {
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      return saleDate.getTime() >= todayStart.getTime();
    }

    if (timeFilter === 'yesterday') {
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const yesterdayStart = new Date(todayStart.getTime() - dayMs);
      return saleDate.getTime() >= yesterdayStart.getTime() && saleDate.getTime() < todayStart.getTime();
    }

    if (timeFilter === 'week') {
      return saleDate.getTime() >= now.getTime() - 7 * dayMs;
    }

    if (timeFilter === 'month') {
      return saleDate.getTime() >= now.getTime() - 30 * dayMs;
    }

    return true;
  });

  const totalCashSales = filteredSales
    .filter((s) => s.paymentType === 'cash')
    .reduce((sum, s) => sum + s.totalAmount, 0);

  const totalCreditSales = filteredSales
    .filter((s) => s.paymentType === 'credit')
    .reduce((sum, s) => sum + s.totalAmount, 0);

  const totalSalesRevenue = totalCashSales + totalCreditSales;
  const totalSalesCost = filteredSales.reduce((sum, s) => sum + s.totalCost, 0);
  const realizedNetProfit = Math.max(0, totalSalesRevenue - totalSalesCost);

  // Customer debt metrics
  const totalOutstandingDebts = customers.reduce((sum, c) => {
    const { netDebt } = getCustomerBalance(c.id, transactions);
    return sum + (netDebt > 0 ? netDebt : 0);
  }, 0);

  const filterLabel = {
    today: 'اليوم',
    yesterday: 'أمس',
    week: 'الأسبوع الماضي',
    month: 'الشهر الماضي',
    all: 'كل الفترات',
  }[timeFilter];

  return (
    <div className="space-y-4 pb-20">
      {/* Top Section: Inventory Core Metrics */}
      <div>
        <div className="flex items-center gap-2 mb-2.5">
          <Package className="w-4 h-4 text-amber-400" />
          <h3 className="font-extrabold text-white text-sm">مؤشرات المخزون ورأس المال</h3>
        </div>

        <div className="grid grid-cols-2 xs:grid-cols-3 gap-2.5">
          {/* Total items */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-[11px] text-slate-400 font-medium">أصناف وقطع المخزن</span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-xl font-black text-white font-mono tabular-nums">{totalItemTypes}</span>
              <span className="text-[10px] text-slate-400">صنف ({totalStockUnits} قطعة)</span>
            </div>
          </div>

          {/* Total cost value */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-[11px] text-slate-400 font-medium">قيمة المخزن (تكلفة)</span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-lg font-black text-amber-300 font-mono tabular-nums">
                {totalInventoryCost.toLocaleString()}
              </span>
              <span className="text-[10px] text-slate-400">{currency}</span>
            </div>
          </div>

          {/* Potential profit */}
          <div className="col-span-2 xs:col-span-1 p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border border-emerald-500/25">
            <span className="text-[11px] text-emerald-400 font-medium">الربح المتوقع للمخزن</span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-lg font-black text-emerald-300 font-mono tabular-nums">
                +{totalPotentialProfit.toLocaleString()}
              </span>
              <span className="text-[10px] text-emerald-400">{currency}</span>
            </div>
            <p className="text-[9px] text-slate-400 mt-0.5">عند بيع كامل المخزون المتوفر</p>
          </div>
        </div>
      </div>

      {/* Sales Analytics Section with Time Filters */}
      <div className="pt-2">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <h3 className="font-extrabold text-white text-sm">حركة المبيعات ({filterLabel})</h3>
          </div>
        </div>

        {/* Time Filters Bar: Today, Yesterday, Past Week, Past Month, All */}
        <div className="grid grid-cols-5 gap-1 p-1 bg-slate-900 rounded-xl border border-slate-800 text-[11px] mb-3">
          {(['today', 'yesterday', 'week', 'month', 'all'] as SalesTimeFilter[]).map((tab) => (
            <button
              key={tab}
              onClick={() => setTimeFilter(tab)}
              className={`py-1.5 rounded-lg font-medium transition-colors text-center truncate ${
                timeFilter === tab
                  ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab === 'today'
                ? 'اليوم'
                : tab === 'yesterday'
                ? 'أمس'
                : tab === 'week'
                ? 'الأسبوع'
                : tab === 'month'
                ? 'الشهر'
                : 'الكل'}
            </button>
          ))}
        </div>

        {/* Sales KPI Cards */}
        <div className="grid grid-cols-2 gap-2.5">
          {/* Total Cash Sales */}
          <div className="p-4 rounded-2xl bg-[#11131a] border border-emerald-500/25 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">المبيعات النقدية (كاش)</span>
              <Banknote className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="flex items-baseline gap-1 mt-2">
              <span className="text-2xl font-black text-emerald-400 font-mono tabular-nums">
                {totalCashSales.toLocaleString()}
              </span>
              <span className="text-xs font-semibold text-slate-400">{currency}</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">مبالغ مستلمة باليد</div>
          </div>

          {/* Total Credit Sales */}
          <div className="p-4 rounded-2xl bg-[#11131a] border border-amber-500/25 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">المبيعات بالدين (آجل)</span>
              <CreditCard className="w-4 h-4 text-amber-400" />
            </div>
            <div className="flex items-baseline gap-1 mt-2">
              <span className="text-2xl font-black text-amber-400 font-mono tabular-nums">
                {totalCreditSales.toLocaleString()}
              </span>
              <span className="text-xs font-semibold text-slate-400">{currency}</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">مرحلة إلى دفتر العملاء</div>
          </div>

          {/* Total Sales Volume */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-xs text-slate-400 font-medium">إجمالي حجم المبيعات</span>
            <div className="flex items-baseline gap-1 mt-2">
              <span className="text-xl font-black text-white font-mono tabular-nums">
                {totalSalesRevenue.toLocaleString()}
              </span>
              <span className="text-xs text-slate-400">{currency}</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">{filteredSales.length} عملية بيع منجزة</div>
          </div>

          {/* Realized Profit */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-xs text-slate-400 font-medium">صافي أرباح المبيعات</span>
            <div className="flex items-baseline gap-1 mt-2">
              <span className="text-xl font-black text-emerald-400 font-mono tabular-nums">
                +{realizedNetProfit.toLocaleString()}
              </span>
              <span className="text-xs text-emerald-400">{currency}</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">بعد خصم أسعار التكلفة</div>
          </div>
        </div>
      </div>

      {/* Debts Market Summary Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-950/20 via-slate-900 to-slate-900 border border-rose-500/25">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium">إجمالي ديون السوق المستحقة:</span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-2xl font-black text-rose-400 font-mono tabular-nums">
                {totalOutstandingDebts.toLocaleString()}
              </span>
              <span className="text-xs font-bold text-slate-400">{currency}</span>
            </div>
          </div>
          <div className="text-left text-xs bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span className="text-slate-400">تحصيل الديون يعزز السيولة</span>
          </div>
        </div>
      </div>

      {/* Recent Sales History Log */}
      <div className="space-y-2 pt-2">
        <h4 className="text-xs font-semibold text-slate-400">سجل أحدث المبيعات ({filteredSales.length})</h4>
        {filteredSales.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500 rounded-xl bg-slate-900/40 border border-slate-800">
            لا توجد مبيعات مسجلة في هذه الفترة ({filterLabel}).
          </div>
        ) : (
          <div className="space-y-2">
            {filteredSales.slice(0, 10).map((sale) => (
              <div
                key={sale.id}
                className="p-3 rounded-xl bg-[#11131a] border border-slate-800/80 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-white">
                    <span>
                      {sale.paymentType === 'cash' ? '💵 بيع نقدي' : `💳 بيع بالدين (${sale.customerName || 'عميل'})`}
                    </span>
                    <span className="text-[10px] font-normal text-slate-400">
                      · {new Date(sale.date).toLocaleDateString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 truncate max-w-[240px]">
                    {sale.items.map((i) => `${i.itemName} (x${i.quantity})`).join(', ')}
                  </div>
                </div>

                <div className="text-left font-mono shrink-0">
                  <div className="font-bold text-amber-300 tabular-nums">
                    {sale.totalAmount} {currency}
                  </div>
                  <div className="text-[10px] text-emerald-400">
                    +{sale.totalAmount - sale.totalCost} ربح
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
