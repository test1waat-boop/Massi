import React, { useState, useRef } from 'react';
import { 
  X, 
  Store, 
  Upload, 
  Camera, 
  Trash2, 
  Globe2, 
  Coins, 
  Download, 
  UploadCloud, 
  HardDrive, 
  Check, 
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  Share2
} from 'lucide-react';
import { StoreSettings } from '../../types';
import { isNativeApp, openExternal, saveBackupFile } from '../../utils/native';
import { createFullDatabaseBackup, restoreFullDatabaseBackup, AppDatabaseBackup } from '../../utils/storage';

interface SettingsModalProps {
  settings: StoreSettings;
  isOpen: boolean;
  onClose: () => void;
  onSaveSettings: (settings: StoreSettings) => void;
  onDatabaseRestored: () => void;
}

const COUNTRY_CODES = [
  { code: '+90', country: 'تركيا (Turkey)', flag: '🇹🇷' },
  { code: '+966', country: 'السعودية (Saudi Arabia)', flag: '🇸🇦' },
  { code: '+971', country: 'الإمارات (UAE)', flag: '🇦🇪' },
  { code: '+964', country: 'العراق (Iraq)', flag: '🇮🇶' },
  { code: '+963', country: 'سوريا (Syria)', flag: '🇸🇾' },
  { code: '+961', country: 'لبنان (Lebanon)', flag: '🇱🇧' },
  { code: '+962', country: 'الأردن (Jordan)', flag: '🇯🇴' },
  { code: '+20', country: 'مصر (Egypt)', flag: '🇪🇬' },
  { code: '+965', country: 'الكويت (Kuwait)', flag: '🇰🇼' },
  { code: '+974', country: 'قطر (Qatar)', flag: '🇶🇦' },
  { code: '+968', country: 'عُمان (Oman)', flag: '🇴🇲' },
  { code: '+973', country: 'البحرين (Bahrain)', flag: '🇧🇭' },
  { code: '+49', country: 'ألمانيا (Germany)', flag: '🇩🇪' },
  { code: '+1', country: 'الولايات المتحدة (USA)', flag: '🇺🇸' },
];

const CURRENCIES = [
  { symbol: '₺', code: 'TRY', name: 'ليرة تركية (الافتراضية)' },
  { symbol: '$', code: 'USD', name: 'دولار أمريكي' },
  { symbol: 'ر.س', code: 'SAR', name: 'ريال سعودي' },
  { symbol: 'د.إ', code: 'AED', name: 'درهم إماراتي' },
  { symbol: 'د.ع', code: 'IQD', name: 'دينار عراقي' },
  { symbol: 'ل.س', code: 'SYP', name: 'ليرة سورية' },
  { symbol: 'ج.م', code: 'EGP', name: 'جنيه مصري' },
  { symbol: '€', code: 'EUR', name: 'يورو' },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  isOpen,
  onClose,
  onSaveSettings,
  onDatabaseRestored,
}) => {
  const [storeName, setStoreName] = useState(settings.storeName);
  const [storeLogo, setStoreLogo] = useState<string | null>(settings.storeLogo);
  const [countryCode, setCountryCode] = useState(settings.countryCode || '+90');
  const [currencyCode, setCurrencyCode] = useState(settings.currency.code || 'TRY');
  const [phone, setPhone] = useState(settings.phone || '');
  const [isSavedNotice, setIsSavedNotice] = useState(false);
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const restoreFileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Handle Logo Upload
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const SIZE = 250;
        canvas.width = SIZE;
        canvas.height = SIZE;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, SIZE, SIZE);
        const dataUrl = canvas.toDataURL('image/png', 0.85);
        setStoreLogo(dataUrl);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Save Settings
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const chosenCurrency = CURRENCIES.find((c) => c.code === currencyCode) || CURRENCIES[0];

    const updated: StoreSettings = {
      storeName: storeName.trim() || 'متجر ماسي',
      storeLogo,
      countryCode,
      currency: {
        symbol: chosenCurrency.symbol,
        code: chosenCurrency.code,
        name: chosenCurrency.name,
      },
      phone: phone.trim(),
    };

    onSaveSettings(updated);
    setIsSavedNotice(true);
    setTimeout(() => {
      setIsSavedNotice(false);
      onClose();
    }, 800);
  };

  // Export full backup to device
  const handleExportLocalFile = async () => {
    const backup = createFullDatabaseBackup();
    const jsonString = JSON.stringify(backup, null, 2);
    const dateStr = new Date().toISOString().split('T')[0];
    await saveBackupFile(`masy-backup-${dateStr}.json`, jsonString);
  };

  // Export / Share to Google Drive or other apps
  const handleExportToGoogleDrive = async () => {
    const backup = createFullDatabaseBackup();
    const jsonString = JSON.stringify(backup, null, 2);
    const dateStr = new Date().toISOString().split('T')[0];
    const fileName = `masy-backup-${dateStr}.json`;

    // Inside the APK the Android share sheet lets the user pick Google Drive directly
    if (isNativeApp()) {
      await saveBackupFile(fileName, jsonString);
      return;
    }

    // Try Web Share API with File
    if (typeof navigator !== 'undefined' && 'share' in navigator) {
      try {
        const file = new File([jsonString], fileName, { type: 'application/json' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: 'نسخة احتياطية لتطبيق ماسي',
            text: 'ملف النسخة الاحتياطية لبيانات المتجر والمخزن ودفتر ديون العملاء',
          });
          return;
        }
      } catch (err) {
        console.warn('Share file rejected, falling back to download:', err);
      }
    }

    // Fallback: download file and open Google Drive upload page
    await handleExportLocalFile();
    openExternal('https://drive.google.com/drive/my-drive');
  };

  // Restore database from user selected JSON file
  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const raw = event.target?.result as string;
        const parsed = JSON.parse(raw) as AppDatabaseBackup;
        const success = restoreFullDatabaseBackup(parsed);
        if (success) {
          setRestoreMessage('تم استرجاع قاعدة البيانات بنجاح!');
          onDatabaseRestored();
          setTimeout(() => {
            setRestoreMessage(null);
            onClose();
          }, 1500);
        } else {
          setRestoreMessage('فشل استرجاع الملف: صيغة النسخة الاحتياطية غير متوافقة.');
        }
      } catch (err) {
        setRestoreMessage('الملف المحدد غير صالح كملف JSON.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div 
        className="w-full max-w-lg bg-[#11131a] border border-amber-500/20 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[94vh] sm:max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#0d0e14]/70">
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-amber-400" />
            <h3 className="font-extrabold text-white text-base">إعدادات المتجر والنسخ الاحتياطي</h3>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Settings Form */}
        <form onSubmit={handleSave} className="p-5 space-y-5 overflow-y-auto flex-1">
          {/* Logo & Store Name */}
          <div className="space-y-3">
            <label className="block text-xs font-semibold text-slate-300">هوية وشعار المتجر</label>
            <div className="flex items-center gap-4">
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="w-20 h-20 rounded-2xl border-2 border-dashed border-amber-500/30 hover:border-amber-400/60 bg-slate-900 flex items-center justify-center cursor-pointer overflow-hidden relative group"
              >
                {storeLogo ? (
                  <>
                    <img src={storeLogo} alt="شعار المتجر" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <Camera className="w-5 h-5 text-white" />
                    </div>
                  </>
                ) : (
                  <div className="text-center">
                    <Camera className="w-6 h-6 text-amber-400/70 mx-auto mb-1" />
                    <span className="text-[9px] text-slate-400">شعار</span>
                  </div>
                )}
              </div>

              <div className="flex-1 space-y-2">
                <input
                  type="text"
                  required
                  placeholder="اسم المتجر..."
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full h-11 px-3.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-bold text-sm focus:border-amber-400 focus:outline-none"
                />

                {storeLogo && (
                  <button
                    type="button"
                    onClick={() => setStoreLogo(null)}
                    className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    إزالة الشعار
                  </button>
                )}

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </div>
            </div>
          </div>

          {/* Country Code for WhatsApp Integration */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Globe2 className="w-4 h-4 text-amber-400" />
                مفتاح الدولة الافتراضي لرسائل الواتساب
              </label>
              <span className="text-[11px] font-mono text-amber-400 font-bold">{countryCode}</span>
            </div>
            <select
              value={countryCode}
              onChange={(e) => setCountryCode(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none"
            >
              {COUNTRY_CODES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.flag} {c.country} ({c.code})
                </option>
              ))}
            </select>
            <p className="text-[10px] text-slate-400 mt-1">
              يتم استخدامه تلقائياً عند فتح واتساب لإرسال كشف الحساب وتذكيرات الديون لأرقام العملاء.
            </p>
          </div>

          {/* Currency Selector (Default Turkish Lira) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Coins className="w-4 h-4 text-amber-400" />
                العملة المعتمدة
              </label>
            </div>
            <select
              value={currencyCode}
              onChange={(e) => setCurrencyCode(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none"
            >
              {CURRENCIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.symbol} - {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Backup & Sync Section */}
          <div className="p-4 rounded-2xl bg-[#090a0e] border border-amber-500/25 space-y-3">
            <div className="flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-amber-400" />
              <h4 className="font-bold text-white text-xs">النسخ الاحتياطي والمزامنة (أمان بياناتك)</h4>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              جميع بياناتك (أصناف المخزن، أسعار التكلفة، سجل المبيعات، ودفتر ديون العملاء) مخزنة محلياً على جهازك. يمكنك حفظ وتصدير نسخة احتياطية في أي وقت.
            </p>

            <div className="grid grid-cols-2 gap-2.5 pt-1">
              {/* Export to Device */}
              <button
                type="button"
                onClick={handleExportLocalFile}
                className="h-11 px-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>حفظ على الجهاز</span>
              </button>

              {/* Export via Google Drive / Share */}
              <button
                type="button"
                onClick={handleExportToGoogleDrive}
                className="h-11 px-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all"
              >
                <UploadCloud className="w-4 h-4" />
                <span>مزامنة Google Drive</span>
              </button>
            </div>

            {/* Restore Backup File */}
            <div className="pt-2 border-t border-slate-800/80">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-300 font-medium">استرجاع نسخة سابقة:</span>
                <button
                  type="button"
                  onClick={() => restoreFileInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 font-semibold text-xs flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>اختيار ملف JSON</span>
                </button>
              </div>

              <input
                ref={restoreFileInputRef}
                type="file"
                accept=".json,application/json"
                onChange={handleRestoreFile}
                className="hidden"
              />

              {restoreMessage && (
                <div className="mt-2 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs text-center font-medium animate-in fade-in">
                  {restoreMessage}
                </div>
              )}
            </div>
          </div>

          {/* Save Button */}
          <div className="pt-2 sticky bottom-0 bg-[#11131a] pb-2">
            <button
              type="submit"
              className="w-full h-12 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-[0.98] transition-transform"
            >
              {isSavedNotice ? (
                <>
                  <Check className="w-5 h-5 stroke-[3]" />
                  <span>تم حفظ الإعدادات بنجاح</span>
                </>
              ) : (
                <span>حفظ التغييرات</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
