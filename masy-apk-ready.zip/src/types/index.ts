export interface StoreSettings {
  storeName: string;
  storeLogo: string | null;
  countryCode: string; // e.g. "+90"
  currency: {
    symbol: string;
    code: string;
    name: string;
  };
  phone?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  colors: string[];
  image: string | null;
  sizes: string[];
  stockQuantity: number;
  costPrice: number;
  sellingPrice: number;
  category?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  notes?: string;
  createdAt: string;
}

export type TransactionType = 'given' | 'taken'; // given = أعطيت (debit / debt on customer), taken = أخذت (credit / customer paid)

export interface CustomerTransaction {
  id: string;
  customerId: string;
  type: TransactionType;
  amount: number;
  date: string; // ISO string
  note: string;
  saleId?: string;
}

export interface SaleItem {
  itemId: string;
  itemName: string;
  color?: string;
  size?: string;
  quantity: number;
  unitPrice: number;
  unitCost: number;
}

export interface SaleRecord {
  id: string;
  date: string;
  items: SaleItem[];
  totalAmount: number;
  totalCost: number;
  paymentType: 'cash' | 'credit'; // نقداً أو بالدين
  customerId?: string;
  customerName?: string;
}

export type ActiveTab = 'inventory' | 'pos' | 'customers' | 'analytics' | 'settings';
