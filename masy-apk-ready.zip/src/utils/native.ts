import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

/** True when running inside the Android app (Capacitor), false in a normal browser. */
export const isNativeApp = (): boolean => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

/**
 * Opens an external link (WhatsApp, Google Drive, ...).
 * Inside the APK window.open(_blank) is unreliable, so we navigate instead and
 * Android hands the link over to the right app (e.g. WhatsApp).
 */
export const openExternal = (url: string): void => {
  if (isNativeApp()) {
    window.location.href = url;
  } else {
    window.open(url, '_blank', 'noopener,noreferrer');
  }
};

/**
 * Saves a JSON backup.
 * - In the browser: normal file download.
 * - In the APK: writes the file and opens the Android share sheet
 *   (save to Drive / Files / WhatsApp / ...), because blob downloads don't work in a WebView.
 * Returns true if something was saved/shared.
 */
export const saveBackupFile = async (fileName: string, jsonString: string): Promise<boolean> => {
  if (isNativeApp()) {
    try {
      const written = await Filesystem.writeFile({
        path: fileName,
        data: jsonString,
        directory: Directory.Cache,
        encoding: Encoding.UTF8,
      });
      await Share.share({
        title: 'نسخة احتياطية لتطبيق ماسي',
        text: 'ملف النسخة الاحتياطية لبيانات المتجر والمخزن ودفتر ديون العملاء',
        url: written.uri,
        dialogTitle: 'حفظ النسخة الاحتياطية',
      });
      return true;
    } catch (err) {
      console.warn('Native backup share cancelled or failed:', err);
      return false;
    }
  }

  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
  return true;
};
