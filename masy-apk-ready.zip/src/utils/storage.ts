import { InventoryItem, Customer, CustomerTransaction, SaleRecord, StoreSettings } from '../types';

const STORAGE_KEYS = {
  SETTINGS: 'masy_store_settings',
  INVENTORY: 'masy_inventory_items',
  CUSTOMERS: 'masy_customers',
  TRANSACTIONS: 'masy_customer_transactions',
  SALES: 'masy_sales_records',
};

export const DEFAULT_SETTINGS: StoreSettings = {
  storeName: 'متجر ماسي للأزياء',
  storeLogo: null,
  countryCode: '+90', // Default Turkish calling code as requested
  currency: {
    symbol: '₺',
    code: 'TRY',
    name: 'ليرة تركية',
  },
  phone: '5312345678',
};

// Seed inventory items with realistic dark luxury apparel
const DEFAULT_INVENTORY: InventoryItem[] = [
  {
    id: 'item-1',
    name: 'قميص كتان ملكي إيطالي',
    colors: ['أبيض ناصع', 'أسود فحمي', 'بيج رملي', 'كحلي داكن'],
    image: null,
    sizes: ['M', 'L', 'XL', 'XXL'],
    stockQuantity: 18,
    costPrice: 220,
    sellingPrice: 450,
    category: 'قمصان',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 12).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'item-2',
    name: 'بنطال قماش رسمي بريميوم',
    colors: ['رمادي داكن', 'كحلي', 'أسود'],
    image: null,
    sizes: ['32', '34', '36', '38'],
    stockQuantity: 14,
    costPrice: 280,
    sellingPrice: 550,
    category: 'بناطيل',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'item-3',
    name: 'جاكيت بليزر عصري خفيف',
    colors: ['كحلي ملكي', 'رمادي رمادي'],
    image: null,
    sizes: ['48', '50', '52', '54'],
    stockQuantity: 7,
    costPrice: 650,
    sellingPrice: 1250,
    category: 'بليزرات',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 8).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'item-4',
    name: 'تيشيرت بولو قطن بيما فاخر',
    colors: ['أبيض', 'زيتي', 'نبيذي', 'أسود'],
    image: null,
    sizes: ['S', 'M', 'L', 'XL'],
    stockQuantity: 25,
    costPrice: 140,
    sellingPrice: 320,
    category: 'تيشيرتات',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'item-5',
    name: 'حزام جلد طبيعي أصلي مع مشبك ذهبي',
    colors: ['أسود', 'بني داكن'],
    image: null,
    sizes: ['110cm', '115cm', '120cm'],
    stockQuantity: 12,
    costPrice: 110,
    sellingPrice: 260,
    category: 'إكسسوارات',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

const DEFAULT_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    name: 'م. أحمد الخالدي',
    phone: '5348899123',
    notes: 'عميل دائم - حي الفاتح',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 16).toISOString(),
  },
  {
    id: 'cust-2',
    name: 'الحاج عمر بكري',
    phone: '5523344556',
    notes: 'تاجر جملة وسداد أسبوعي',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(),
  },
  {
    id: 'cust-3',
    name: 'سليمان الشامي',
    phone: '5391234567',
    notes: 'زبون محلي',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
  },
];

const DEFAULT_TRANSACTIONS: CustomerTransaction[] = [
  {
    id: 'tx-1',
    customerId: 'cust-1',
    type: 'given', // أعطيت
    amount: 1250,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString(),
    note: 'جاكيت بليزر عصري + بنطال قماش بريميوم بالدين',
  },
  {
    id: 'tx-2',
    customerId: 'cust-1',
    type: 'taken', // أخذت
    amount: 500,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4).toISOString(),
    note: 'دفعة نقدية تحت الحساب',
  },
  {
    id: 'tx-3',
    customerId: 'cust-2',
    type: 'given', // أعطيت
    amount: 900,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 6).toISOString(),
    note: '2 قميص كتان ملكي إيطالي',
  },
  {
    id: 'tx-4',
    customerId: 'cust-3',
    type: 'given', // أعطيت
    amount: 320,
    date: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    note: 'تيشيرت بولو نبيذي مقاس L بالدين',
  },
];

const DEFAULT_SALES: SaleRecord[] = [
  {
    id: 'sale-1',
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
    items: [
      {
        itemId: 'item-1',
        itemName: 'قميص كتان ملكي إيطالي',
        color: 'أبيض ناصع',
        size: 'L',
        quantity: 2,
        unitPrice: 450,
        unitCost: 220,
      },
    ],
    totalAmount: 900,
    totalCost: 440,
    paymentType: 'cash',
  },
  {
    id: 'sale-2',
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(),
    items: [
      {
        itemId: 'item-4',
        itemName: 'تيشيرت بولو قطن بيما فاخر',
        color: 'أسود',
        size: 'XL',
        quantity: 1,
        unitPrice: 320,
        unitCost: 140,
      },
      {
        itemId: 'item-5',
        itemName: 'حزام جلد طبيعي أصلي',
        color: 'أسود',
        size: '115cm',
        quantity: 1,
        unitPrice: 260,
        unitCost: 110,
      },
    ],
    totalAmount: 580,
    totalCost: 250,
    paymentType: 'cash',
  },
  {
    id: 'sale-3',
    date: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    items: [
      {
        itemId: 'item-4',
        itemName: 'تيشيرت بولو قطن بيما فاخر',
        color: 'نبيذي',
        size: 'L',
        quantity: 1,
        unitPrice: 320,
        unitCost: 140,
      },
    ],
    totalAmount: 320,
    totalCost: 140,
    paymentType: 'credit',
    customerId: 'cust-3',
    customerName: 'سليمان الشامي',
  },
];

// Helper functions for LocalStorage
export const getStoredSettings = (): StoreSettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return raw ? JSON.parse(raw) : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveStoredSettings = (settings: StoreSettings): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch {
    // ignore storage errors
  }
};

export const getStoredInventory = (): InventoryItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.INVENTORY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(DEFAULT_INVENTORY));
      return DEFAULT_INVENTORY;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_INVENTORY;
  }
};

export const saveStoredInventory = (items: InventoryItem[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(items));
  } catch {
    // ignore storage errors
  }
};

export const getStoredCustomers = (): Customer[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(DEFAULT_CUSTOMERS));
      return DEFAULT_CUSTOMERS;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_CUSTOMERS;
  }
};

export const saveStoredCustomers = (customers: Customer[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  } catch {
    // ignore storage errors
  }
};

export const getStoredTransactions = (): CustomerTransaction[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(DEFAULT_TRANSACTIONS));
      return DEFAULT_TRANSACTIONS;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_TRANSACTIONS;
  }
};

export const saveStoredTransactions = (transactions: CustomerTransaction[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  } catch {
    // ignore storage errors
  }
};

export const getStoredSales = (): SaleRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SALES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(DEFAULT_SALES));
      return DEFAULT_SALES;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_SALES;
  }
};

export const saveStoredSales = (sales: SaleRecord[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales));
  } catch {
    // ignore storage errors
  }
};

// Database backup and restore
export interface AppDatabaseBackup {
  version: number;
  appName: string;
  exportedAt: string;
  settings: StoreSettings;
  inventory: InventoryItem[];
  customers: Customer[];
  transactions: CustomerTransaction[];
  sales: SaleRecord[];
}

export const createFullDatabaseBackup = (): AppDatabaseBackup => {
  return {
    version: 1,
    appName: 'Masy (ماسي)',
    exportedAt: new Date().toISOString(),
    settings: getStoredSettings(),
    inventory: getStoredInventory(),
    customers: getStoredCustomers(),
    transactions: getStoredTransactions(),
    sales: getStoredSales(),
  };
};

export const restoreFullDatabaseBackup = (backup: AppDatabaseBackup): boolean => {
  try {
    if (!backup || !backup.inventory || !backup.customers) {
      throw new Error('ملف النسخة الاحتياطية غير صالح');
    }
    if (backup.settings) saveStoredSettings(backup.settings);
    if (backup.inventory) saveStoredInventory(backup.inventory);
    if (backup.customers) saveStoredCustomers(backup.customers);
    if (backup.transactions) saveStoredTransactions(backup.transactions);
    if (backup.sales) saveStoredSales(backup.sales);
    return true;
  } catch (err) {
    console.error('Failed to restore backup:', err);
    return false;
  }
};

// Customer balance calculation
export const getCustomerBalance = (customerId: string, transactions: CustomerTransaction[]) => {
  const customerTxs = transactions.filter((t) => t.customerId === customerId);
  const totalGiven = customerTxs
    .filter((t) => t.type === 'given')
    .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
  const totalTaken = customerTxs
    .filter((t) => t.type === 'taken')
    .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
  
  // Net balance: positive means customer owes money (debt / عليه), negative means store owes customer (له)
  const netDebt = totalGiven - totalTaken;

  // Find first debt date (oldest 'given' transaction that is part of unpaid balance)
  const givenTxs = customerTxs
    .filter((t) => t.type === 'given')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  const firstDebtDate = givenTxs.length > 0 ? givenTxs[0].date : null;

  return {
    totalGiven,
    totalTaken,
    netDebt,
    firstDebtDate,
    transactionCount: customerTxs.length,
  };
};
