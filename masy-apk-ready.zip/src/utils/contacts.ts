export interface PickedContact {
  name: string;
  phone: string;
}

/**
 * Checks if device supports native Contact Picker API
 */
export const isContactsApiSupported = (): boolean => {
  return 'contacts' in navigator && 'ContactsManager' in window;
};

/**
 * Prompts user to pick a contact from their device phonebook
 */
export const pickDeviceContact = async (): Promise<PickedContact | null> => {
  if (!isContactsApiSupported()) {
    return null;
  }

  try {
    const nav = navigator as unknown as {
      contacts: {
        select: (
          properties: string[],
          options?: { multiple: boolean }
        ) => Promise<Array<{ name?: string[]; tel?: string[] }>>;
      };
    };

    const contacts = await nav.contacts.select(['name', 'tel'], { multiple: false });
    if (!contacts || contacts.length === 0) return null;

    const contact = contacts[0];
    const name = contact.name && contact.name[0] ? contact.name[0].trim() : '';
    const phone = contact.tel && contact.tel[0] ? contact.tel[0].trim() : '';

    return { name, phone };
  } catch (err) {
    // User cancelled or browser rejected
    console.warn('Contact picker cancelled or failed:', err);
    return null;
  }
};
