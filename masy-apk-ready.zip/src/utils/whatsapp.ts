import { Customer, CustomerTransaction, StoreSettings } from '../types';
import { getCustomerBalance } from './storage';
import { openExternal } from './native';

/**
 * Normalizes phone number with country calling code.
 * Cleans non-digit characters, removes leading 0 if country code provided.
 */
export const formatPhoneNumberForWhatsApp = (rawPhone: string, countryCode: string): string => {
  if (!rawPhone) return '';
  
  // Clean all non-digit characters
  let digits = rawPhone.replace(/\D/g, '');
  const cleanCode = countryCode.replace(/\D/g, '');

  // If already starts with the country code digits
  if (digits.startsWith(cleanCode)) {
    return digits;
  }

  // If starts with 00 followed by country code
  if (digits.startsWith('00' + cleanCode)) {
    return digits.substring(2);
  }

  // If starts with national trunk prefix 0, strip it before prepending country code
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
  }

  return `${cleanCode}${digits}`;
};

/**
 * Generates WhatsApp Detailed Account Statement (كشف حساب مفصل)
 */
export const generateAccountStatementText = (
  customer: Customer,
  transactions: CustomerTransaction[],
  settings: StoreSettings
): string => {
  const { totalGiven, totalTaken, netDebt } = getCustomerBalance(customer.id, transactions);
  const currency = settings.currency.symbol;
  const storeName = settings.storeName || 'متجر ماسي';
  const currentDate = new Date().toLocaleDateString('ar-SA', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const customerTxs = transactions
    .filter((t) => t.customerId === customer.id)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  let statement = `✨ *${storeName}* ✨\n`;
  statement += `📋 *كشف حساب مالي*\n`;
  statement += `👤 العميل: *${customer.name}*\n`;
  statement += `📅 التاريخ: ${currentDate}\n`;
  statement += `──────────────────\n`;

  if (customerTxs.length === 0) {
    statement += `لا توجد حركات مسجلة حتى الآن.\n`;
  } else {
    statement += `*سجل العمليات:*\n`;
    customerTxs.forEach((tx, idx) => {
      const txDate = new Date(tx.date).toLocaleDateString('ar-EG', {
        day: '2-digit',
        month: '2-digit',
      });
      const typeLabel = tx.type === 'given' ? '🔴 أعطيت (دين)' : '🟢 أخذت (سداد)';
      const sign = tx.type === 'given' ? '+' : '-';
      statement += `${idx + 1}. ${txDate} | ${typeLabel}: *${sign}${tx.amount} ${currency}*\n`;
      if (tx.note) {
        statement += `   📝 ${tx.note}\n`;
      }
    });
  }

  statement += `──────────────────\n`;
  statement += `💰 إجمالي المسحوبات (الدين): *${totalGiven} ${currency}*\n`;
  statement += `💵 إجمالي المدفوعات (السداد): *${totalTaken} ${currency}*\n`;
  statement += `──────────────────\n`;

  if (netDebt > 0) {
    statement += `⚠️ *الرصيد المتبقي بذمتكم (المطلوب سداده):* *${netDebt} ${currency}*\n`;
  } else if (netDebt < 0) {
    statement += `✅ *الرصيد الدائن لصالحكم:* *${Math.abs(netDebt)} ${currency}*\n`;
  } else {
    statement += `🎉 *الحساب خالص تماماً (الرصيد: 0 ${currency})*\n`;
  }

  statement += `\nشاكرين ومقدرين حسن تعاملكم معنا 🤍`;

  return statement;
};

/**
 * Generates WhatsApp Reminder (تذكير بالدين)
 * Requirement: "A button that opens WhatsApp with a pre-filled text message showing ONLY
 * the exact remaining balance amount and the number of days that have passed since the debt began."
 */
export const generateDebtReminderText = (
  customer: Customer,
  transactions: CustomerTransaction[],
  settings: StoreSettings
): string => {
  const { netDebt, firstDebtDate } = getCustomerBalance(customer.id, transactions);
  const currency = settings.currency.symbol;

  let daysPassed = 1;
  if (firstDebtDate) {
    const start = new Date(firstDebtDate).getTime();
    const now = Date.now();
    const diffDays = Math.floor((now - start) / (1000 * 60 * 60 * 24));
    daysPassed = Math.max(1, diffDays);
  }

  // Pre-filled text showing only the exact remaining balance and days passed since debt began
  return `السلام عليكم ورحمة الله، نود تذكيركم بأن الرصيد المتبقي بذمتكم هو ${netDebt} ${currency}، وقد مضى على الدين ${daysPassed} يوماً.`;
};

/**
 * Opens WhatsApp with formatted message
 */
export const openWhatsApp = (phone: string, countryCode: string, text: string): void => {
  const formattedPhone = formatPhoneNumberForWhatsApp(phone, countryCode);
  const encodedText = encodeURIComponent(text);
  
  // If phone exists, target user directly; else open WA share
  let url = '';
  if (formattedPhone) {
    url = `https://wa.me/${formattedPhone}?text=${encodedText}`;
  } else {
    url = `https://api.whatsapp.com/send?text=${encodedText}`;
  }

  openExternal(url);
};
