import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, errorMessage: error?.message || 'خطأ غير متوقع' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          dir="rtl"
          className="min-h-screen bg-[#08090d] text-slate-100 flex items-center justify-center p-6 text-center"
        >
          <div className="max-w-sm w-full bg-[#11131a] border border-rose-500/30 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-extrabold text-rose-400">حدث خطأ أثناء تشغيل التطبيق</h2>
            <p className="text-xs text-slate-300 font-mono break-words">{this.state.errorMessage}</p>
            <button
              onClick={() => window.location.reload()}
              className="w-full h-11 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
            >
              إعادة تحميل التطبيق
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <AppErrorBoundary>
    <App />
  </AppErrorBoundary>
);
